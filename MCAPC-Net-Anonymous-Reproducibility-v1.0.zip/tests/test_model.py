import numpy as np
import unittest

try:
    import torch
except ImportError:
    torch = None

from mcapc.model import MCAPCNet, composite_loss


class ModelTests(unittest.TestCase):
    @unittest.skipUnless(torch is not None, "PyTorch is not installed")
    def test_forward_and_bound(self) -> None:
        torch.manual_seed(3)
        model = MCAPCNet(alpha=0.01)
        numeric = torch.randn(6, 112)
        market = torch.softmax(torch.randn(6, 4, 3), dim=2)
        teacher = torch.softmax(torch.randn(6, 3), dim=1)
        league = torch.tensor([0, 1, 2, -1, -1, 0])
        output = model(numeric, market, teacher, league)
        self.assertEqual(output["probabilities"].shape, (6, 3))
        np.testing.assert_allclose(output["probabilities"].detach().numpy().sum(axis=1), 1.0, atol=1.0e-6)
        correction = output["logits"] - torch.log(teacher)
        self.assertLess(float(torch.linalg.vector_norm(correction, dim=1).max()), np.sqrt(3.0) * 0.01)
        loss, components = composite_loss(output, torch.tensor([0, 1, 2, 0, 1, 2]), teacher, {"cross_entropy": 1.0, "rps": 0.45, "teacher_kl": 0.75, "anchor": 0.25, "attention": 0.005})
        self.assertTrue(bool(torch.isfinite(loss)))
        self.assertIn("attention_regularizer", components)
