import numpy as np
import unittest

from mcapc.splits import ExpandingWindowSplitter, inner_chronological_split


class SplitTests(unittest.TestCase):
    def test_outer_fold_boundaries(self) -> None:
        folds = list(ExpandingWindowSplitter().split(1140))
        self.assertEqual([len(fold.train_indices) for fold in folds], [190, 380, 570, 760, 950])
        self.assertEqual([len(fold.validation_indices) for fold in folds], [190] * 5)
        for fold in folds:
            self.assertLess(fold.train_indices.max(), fold.validation_indices.min())

    def test_inner_split_is_ordered_and_disjoint(self) -> None:
        train, validation = inner_chronological_split(np.arange(190), 0.20)
        self.assertEqual(len(train), 152)
        self.assertEqual(len(validation), 38)
        self.assertLess(train.max(), validation.min())
