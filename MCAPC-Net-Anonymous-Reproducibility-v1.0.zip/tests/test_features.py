from pathlib import Path

import numpy as np
import pandas as pd
import unittest

from mcapc.config import load_config
from mcapc.features import build_features


class FeatureTests(unittest.TestCase):
    def test_feature_count_and_strict_history_order(self) -> None:
        cfg = load_config(Path(__file__).resolve().parents[1] / "configs" / "main.yaml")
        rows = []
        for index, result in enumerate(("H", "D", "A")):
            row = {
                "MatchDate": pd.Timestamp("2023-08-01") + pd.Timedelta(days=index),
                "League": "E0",
                "HomeTeam": "Home",
                "AwayTeam": "Away",
                "SourceRow": index,
                "FTR": result,
                "FTHG": [2, 1, 0][index],
                "FTAG": [0, 1, 1][index],
            }
            for columns in cfg["data"]["source_columns"].values():
                row.update(dict(zip(columns, (2.1, 3.3, 3.8))))
            rows.append(row)
        frame, market = build_features(pd.DataFrame(rows), cfg)
        self.assertEqual(market.shape, (3, 4, 3))
        self.assertEqual(frame.shape[1], 118)
        self.assertTrue(np.isnan(frame.loc[0, "home_ppg_3"]))
        self.assertEqual(frame.loc[1, "home_ppg_3"], 3.0)
