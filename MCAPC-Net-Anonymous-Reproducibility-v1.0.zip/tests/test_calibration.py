import numpy as np
import unittest

from mcapc.calibration import FRMCCM, SMTBCM, OptimizedProbabilityPool


def market_input(seed: int = 9) -> tuple[np.ndarray, np.ndarray]:
    generator = np.random.default_rng(seed)
    base = generator.dirichlet([2.5, 1.7, 2.0], size=90)
    market = np.stack([base + generator.uniform(0.0, 0.03, base.shape) for _ in range(4)], axis=1)
    market /= market.sum(axis=2, keepdims=True)
    y = np.array([generator.choice(3, p=row) for row in base])
    return market, y


class CalibrationTests(unittest.TestCase):
    def test_market_calibrators_return_simplex(self) -> None:
        market, y = market_input()
        for estimator in (FRMCCM(), SMTBCM(), OptimizedProbabilityPool()):
            prediction = estimator.fit(market, y).predict_proba(market[:7])
            self.assertEqual(prediction.shape, (7, 3))
            np.testing.assert_allclose(prediction.sum(axis=1), 1.0, atol=1.0e-9)
            self.assertTrue(np.all(prediction > 0.0))
