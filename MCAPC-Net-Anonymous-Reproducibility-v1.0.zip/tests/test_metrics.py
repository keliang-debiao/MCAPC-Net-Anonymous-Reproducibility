import numpy as np
import unittest

from mcapc.metrics import brier_score, calibration_error, holm_adjust, ranked_probability_score


class MetricTests(unittest.TestCase):
    def test_perfect_probabilities_have_zero_scores(self) -> None:
        y = np.array([0, 1, 2])
        probability = np.eye(3)
        self.assertLess(ranked_probability_score(y, probability), 1.0e-20)
        self.assertLess(brier_score(y, probability), 1.0e-20)

    def test_calibration_output_is_bounded(self) -> None:
        y = np.array([0, 1, 2, 0])
        probability = np.array([[0.7, 0.2, 0.1], [0.2, 0.6, 0.2], [0.1, 0.2, 0.7], [0.4, 0.3, 0.3]])
        ece, mce = calibration_error(y, probability, bins=5)
        self.assertTrue(0.0 <= ece <= 1.0)
        self.assertTrue(0.0 <= mce <= 1.0)

    def test_holm_adjustment_preserves_ordered_limits(self) -> None:
        adjusted = holm_adjust([0.01, 0.04, 0.02])
        self.assertTrue(all(0.0 <= value <= 1.0 for value in adjusted))
        self.assertLessEqual(adjusted[0], adjusted[1])
