# Prediction directory

The complete run writes match-level development and held-out probability records here. Each record retains its cohort, date, teams, target index, model name, and ordered home/draw/away probabilities.
