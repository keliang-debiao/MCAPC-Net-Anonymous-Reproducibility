# Model state directory

The complete run writes fold-specific and seed-specific PyTorch state dictionaries, fold-local preprocessors, and the final SMTBCM teacher here.
