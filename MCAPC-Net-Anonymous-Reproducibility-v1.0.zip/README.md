# MCAPC-Net Anonymous Reproducibility Package

This repository contains the complete computational workflow for market-assisted three-way football outcome forecasting with the Market-Consensus Attentive Prototype Calibration Network.

The release is organized for anonymous peer review. It contains no author names, institutional identifiers, submission identifiers, credentials, raw data, or machine-specific absolute paths.

## Scope

The workflow covers:

- retrieval and SHA-256 registration of the 2023-24 E0, SP1, I1, D1, and F1 source files;
- chronological construction of 112 pre-match variables;
- five-fold expanding-window development on E0, SP1, and I1;
- frozen evaluation on D1 and F1;
- fold-specific preprocessing and SMTBCM teacher fitting;
- MCAPC-Net training with five deterministic seeds;
- raw-market, calibration, pooling, stacking, and conventional learning baselines;
- architecture and feature-group ablations;
- calibration sensitivity, residual-magnitude analysis, paired bootstrap inference, and fixed-rule decision analysis;
- machine-readable tables, predictions, model states, and execution records.

## Repository layout

```text
configs/                 Fixed experiment configuration
data/raw/                Downloaded source files, excluded from version control
data/processed/          Generated feature matrices, excluded from version control
docs/                    Protocol and result traceability
logs/                    Execution records
results/reference_targets/ Manuscript-aligned verification targets
scripts/                 Entry points and repository audits
src/mcapc/               Data, model, training, baseline, and analysis modules
tests/                   Deterministic unit and integration checks
artifacts/                Generated predictions and model states
```

## Environment

The manuscript configuration uses Python 3.12.12 and PyTorch 2.13.0 in CPU mode. Create the environment with either route below.

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python -m pip install -e .
```

or

```bash
conda env create -f environment.yml
conda activate mcapc-net
python -m pip install -e .
```

## Reproduce the study

Run the complete workflow from the repository root:

```bash
bash scripts/run_full.sh
```

The command performs the following ordered stages:

1. download and register the five public league files;
2. build leakage-controlled pre-match variables;
3. execute expanding-window development;
4. fit the frozen final configuration;
5. evaluate the German and French held-out cohorts;
6. run baselines, ablations, sensitivity analyses, bootstrap inference, and decision analysis;
7. write tables, predictions, model states, environment metadata, and logs;
8. audit anonymity, prohibited text, schema integrity, and output completeness.

Individual stages are available through the command-line interface:

```bash
python -m mcapc.cli download --config configs/main.yaml
python -m mcapc.cli prepare --config configs/main.yaml
python -m mcapc.cli run --config configs/main.yaml
python -m mcapc.cli audit --config configs/main.yaml
```

## Verification run

A short CPU verification can be executed without changing the main configuration:

```bash
bash scripts/run_checks.sh
```

This route runs static compilation, unit tests, configuration validation, and a deterministic forward-pass check. It does not replace the complete five-fold study.

## Reference targets and execution records

`results/reference_targets/` and `logs/reference_run.log` contain manuscript-aligned targets for checking pipeline wiring and table schemas. Every such file is marked as a reference target that has not been produced by a complete empirical execution. These records must be replaced by files written by `scripts/run_full.sh` before a public archival release.

The package never silently substitutes reference targets for computed outputs. Computed results are written to `results/computed/`, and the audit command rejects a release manifest that labels reference targets as empirical records.

## Data availability

The raw match files are not redistributed. `python -m mcapc.cli download` retrieves the public files from Football-Data.co.uk and writes a local manifest containing source URL, retrieval time, byte size, row count, and SHA-256 digest. All outcome fields and same-match event statistics are removed before feature construction.

## Reproducibility controls

- chronological ordering precedes all split construction;
- imputers and scalers are fitted inside the corresponding training stage;
- teacher and baseline parameters are fitted independently in each fold;
- D1 and F1 outcomes never enter preprocessing, calibration, model selection, or early stopping;
- random seeds are fixed at 2026, 2027, 2028, 2029, and 2030;
- bootstrap indices are generated from a recorded NumPy generator state;
- every output table is linked to its producing command in `docs/RESULT_MAPPING.md`.

## License

Source code is released under the MIT License. Source data remain subject to the terms of the original provider.
