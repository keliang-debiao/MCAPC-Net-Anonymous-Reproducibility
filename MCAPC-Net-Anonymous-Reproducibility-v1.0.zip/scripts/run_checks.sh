#!/usr/bin/env bash
set -euo pipefail

python -m compileall -q src tests scripts
python -m unittest discover -s tests -v
python -m mcapc.cli audit --config configs/main.yaml
