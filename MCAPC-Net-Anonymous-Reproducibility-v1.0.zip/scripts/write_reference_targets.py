"""Write manuscript-aligned value and schema targets for verification."""

from __future__ import annotations

import csv
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
TARGET = ROOT / "results" / "reference_targets"


def write_csv(name: str, fields: list[str], rows: list[dict[str, object]]) -> None:
    TARGET.mkdir(parents=True, exist_ok=True)
    with (TARGET / name).open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    development = [
        ("MCAPC-Net", 0.179200, 0.005100, 0.925800, 0.182700, 0.052400, 0.581100, 0.515600, 0.721800),
        ("MultinomialLogisticStacking", 0.180600, 0.004850, 0.931500, 0.184100, 0.058900, 0.574700, 0.493800, 0.717100),
        ("OptimizedLinearProbabilityPool", 0.181100, 0.004920, 0.934600, 0.184900, 0.064200, 0.572600, 0.460900, 0.714400),
        ("FR-MCCM", 0.181426, 0.004996, 0.938083, 0.185618, 0.075314, 0.571579, 0.439195, 0.710249),
        ("SMTBCM", 0.181933, 0.006082, 0.939081, 0.186042, 0.069523, 0.556842, 0.441279, 0.708523),
        ("MarketB365Close", 0.182178, 0.003686, 0.942044, 0.186022, 0.077368, 0.567368, 0.428107, 0.712358),
    ]
    fields = ["model", "rps_mean", "rps_sd", "log_loss", "brier", "ece_15", "accuracy", "macro_f1", "auc_ovr"]
    write_csv("development_primary.csv", fields, [dict(zip(fields, row)) for row in development])
    heldout = [
        ("D1", "MCAPC-Net", 306, 0.181800, 0.169500, 0.194400),
        ("F1", "MCAPC-Net", 306, 0.203800, 0.190500, 0.217400),
        ("Combined", "MCAPC-Net", 612, 0.192800, 0.184200, 0.201500),
        ("Combined", "MultinomialLogisticStacking", 612, 0.194600, 0.185900, 0.203500),
        ("Combined", "OptimizedLinearProbabilityPool", 612, 0.195100, 0.186400, 0.204000),
        ("Combined", "SMTBCM", 612, 0.195500, 0.186700, 0.204500),
        ("Combined", "MarketB365Close", 612, 0.195789, 0.187000, 0.204700),
        ("Combined", "FR-MCCM", 612, 0.196095, 0.187200, 0.205100),
    ]
    fields = ["cohort", "model", "n", "rps", "ci_lower", "ci_upper"]
    write_csv("heldout_primary.csv", fields, [dict(zip(fields, row)) for row in heldout])
    alpha_rows = []
    values = [
        (1, 0.184900, 0.183100, 0.182400, 0.182800, 0.184600),
        (2, 0.181600, 0.179800, 0.179100, 0.179600, 0.181000),
        (3, 0.179800, 0.178200, 0.177500, 0.178000, 0.179400),
        (4, 0.186200, 0.184500, 0.183700, 0.184100, 0.185600),
        (5, 0.182100, 0.180400, 0.179800, 0.180300, 0.181800),
    ]
    candidates = [0.0, 0.005, 0.01, 0.02, 0.05]
    for row in values:
        for alpha, score in zip(candidates, row[1:]):
            alpha_rows.append({"outer_fold": row[0], "alpha": alpha, "validation_rps": score, "selected": alpha == 0.01})
    write_csv("alpha_trace.csv", ["outer_fold", "alpha", "validation_rps", "selected"], alpha_rows)
    diagnostic = [
        {"quantity": "mean_logit_norm", "value": 0.0071},
        {"quantity": "mean_probability_l1", "value": 0.0036},
        {"quantity": "top_class_changed_rate", "value": 0.0180},
        {"quantity": "decision_gross_roi_at_0.03", "value": 0.0190},
    ]
    write_csv("mechanism_and_decision.csv", ["quantity", "value"], diagnostic)
    seed_values = [
        (2026, 0.179440, 0.926500, 0.182900, 0.053400),
        (2027, 0.179080, 0.925200, 0.182500, 0.051700),
        (2028, 0.179310, 0.926000, 0.182800, 0.052600),
        (2029, 0.178940, 0.924900, 0.182400, 0.051300),
        (2030, 0.179230, 0.925800, 0.182900, 0.052900),
    ]
    fields = ["seed", "rps", "log_loss", "brier", "ece_15"]
    write_csv("seed_stability.csv", fields, [dict(zip(fields, row)) for row in seed_values])
    architecture = [
        ("MCAPC-Net", 0.192800, 0.963500, 0.191700, 0.047900),
        ("WithoutPrototypeAssistance", 0.193400, 0.965900, 0.192300, 0.050800),
        ("WithoutLeagueConditioning", 0.193900, 0.968100, 0.192800, 0.052600),
        ("WithoutHistoricalForm", 0.194200, 0.969700, 0.193200, 0.054400),
        ("Bet365SourceOnly", 0.194500, 0.971200, 0.193700, 0.056800),
        ("SMTBCMTeacherOnly", 0.195500, 0.976800, 0.194900, 0.062300),
        ("MarketB365Close", 0.195800, 0.978500, 0.195300, 0.066400),
    ]
    fields = ["variant", "rps", "log_loss", "brier", "ece_15"]
    write_csv("architecture_ablation.csv", fields, [dict(zip(fields, row)) for row in architecture])
    feature_values = [
        ("FullMCAPC-Net", 0.192800, 0.000000, 0.047900),
        ("WithoutCalendarVariables", 0.193050, 0.000250, 0.049000),
        ("WithoutUncertaintyVariables", 0.193450, 0.000650, 0.050800),
        ("ClosingMarketSourcesOnly", 0.193500, 0.000700, 0.051300),
        ("WithoutMarketDerivedNumericalFeatures", 0.194050, 0.001250, 0.053100),
        ("WithoutHistoricalForm", 0.194200, 0.001400, 0.054400),
        ("Bet365SourceOnly", 0.194500, 0.001700, 0.056800),
        ("OpeningMarketSourcesOnly", 0.196400, 0.003600, 0.064000),
        ("NonMarketMultilayerPerceptron", 0.219800, 0.027000, 0.091500),
    ]
    fields = ["configuration", "heldout_rps", "rps_change", "heldout_ece_15"]
    write_csv("feature_ablation.csv", fields, [dict(zip(fields, row)) for row in feature_values])
    capacity = [(24, 8853, 0.180450, 0.194200), (48, 21093, 0.179680, 0.193250), (72, 37653, 0.179200, 0.192800), (96, 58533, 0.179460, 0.193180)]
    fields = ["hidden_dimension", "trainable_parameters", "development_rps", "heldout_rps"]
    write_csv("capacity.csv", fields, [dict(zip(fields, row)) for row in capacity])
    learning = [
        (190, 0.155800, 0.187800, 0.001200, 0.032000),
        (380, 0.163900, 0.183900, 0.000820, 0.020000),
        (570, 0.168800, 0.181200, 0.000610, 0.012400),
        (760, 0.172300, 0.179800, 0.000420, 0.007500),
        (950, 0.174100, 0.178600, 0.000310, 0.004500),
    ]
    fields = ["training_matches", "training_rps", "validation_rps_mean", "validation_rps_sd", "gap"]
    write_csv("learning_curve.csv", fields, [dict(zip(fields, row)) for row in learning])
    noise = [(0.00, 0.192800, 0.000000, 1), (0.05, 0.196100, 0.000800, 50), (0.10, 0.196800, 0.001000, 50), (0.15, 0.198700, 0.001200, 50)]
    fields = ["noise_sd", "rps_mean", "rps_sd", "repetitions"]
    write_csv("logit_noise_stress.csv", fields, [dict(zip(fields, row)) for row in noise])
    (TARGET / "STATUS.txt").write_text(
        "REFERENCE TARGETS ONLY\n"
        "NOT_EXECUTED\n"
        "These manuscript-aligned values define verification targets and table schemas.\n"
        "They are not outputs of a completed empirical execution.\n"
        "Run scripts/run_full.sh to create independent computed records.\n",
        encoding="utf-8",
    )


if __name__ == "__main__":
    main()
