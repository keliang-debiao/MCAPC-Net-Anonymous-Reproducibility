#!/usr/bin/env bash
set -euo pipefail

python -m mcapc.cli download --config configs/main.yaml
python -m mcapc.cli prepare --config configs/main.yaml
python -m mcapc.cli run --config configs/main.yaml
python -m mcapc.cli audit --config configs/main.yaml --require-computed
