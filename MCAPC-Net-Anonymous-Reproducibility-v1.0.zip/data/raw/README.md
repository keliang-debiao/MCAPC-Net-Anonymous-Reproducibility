# Raw data directory

Run `python -m mcapc.cli download --config configs/main.yaml` to retrieve the five public season files and create `source_manifest.json`. Downloaded files are intentionally excluded from the review archive.
