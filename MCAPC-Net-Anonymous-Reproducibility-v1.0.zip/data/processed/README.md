# Processed data directory

Run `python -m mcapc.cli prepare --config configs/main.yaml` after source retrieval. Generated feature matrices and the feature registry are intentionally excluded from the review archive.
