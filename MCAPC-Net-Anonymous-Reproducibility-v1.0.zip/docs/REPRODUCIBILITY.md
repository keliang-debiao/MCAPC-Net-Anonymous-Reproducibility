# Reproducibility Protocol

## Fixed analytical boundary

E0, SP1, and I1 form the development cohort. D1 and F1 remain absent from feature normalization, teacher fitting, hyperparameter selection, epoch selection, and parameter updating. Held-out labels are read only when metrics are computed.

## Chronological construction

Matches are sorted by date and a stable source-row index. Rolling team statistics are read before a fixture and updated only after that fixture has been transformed. Same-match scores, result codes, shots, corners, cards, and other event fields are never admitted to the predictor matrix.

## Feature registry

The generated predictor matrix contains exactly 112 columns:

- 60 market-derived variables;
- 6 calendar variables;
- 46 historical-form variables.

The feature builder writes the ordered registry to `data/processed/feature_registry.json`. The pipeline stops if the count, order, or finite-value checks fail.

## Development protocol

Five expanding-window folds use training sizes 190, 380, 570, 760, and 950, each followed by a fixed 190-match validation block. The latest 20% of every outer training window is the inner validation segment. Imputation, scaling, SMTBCM fitting, alpha selection, and early stopping are performed without outer-validation labels.

## Frozen transfer protocol

After selecting the fixed configuration, each seed is fitted on all 1,140 development matches. D1 and F1 use the mean of the learned E0, SP1, and I1 league embeddings. Seed-level probability vectors are averaged before held-out metrics, calibration analysis, bootstrap inference, residual diagnostics, and decision analysis.

## Uncertainty

Development uncertainty is summarized across the five chronological folds. Held-out uncertainty uses 10,000 league-stratified bootstrap resamples. Pairwise comparisons apply identical resampling indices to both forecasts. Calibration bins are recomputed within each bootstrap replicate.

## Release boundary

Files under `results/reference_targets/` are schema and value targets aligned with the manuscript. They are not outputs from a complete run. A public archive must contain computed outputs under `results/computed/` and must pass `python -m mcapc.cli audit`.
