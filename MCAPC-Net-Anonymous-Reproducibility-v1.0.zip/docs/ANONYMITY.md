# Anonymous Review Controls

The repository is prepared for double-anonymous review.

- Author names, affiliations, email addresses, account names, submission identifiers, and local absolute paths are absent.
- Source data are retrieved only through public provider URLs.
- Generated metadata use the neutral label `Anonymous Research Team`.
- No credentials, access tokens, remote write URLs, or version-control history are included.
- The repository audit scans text files, filenames, configuration fields, and archive members before release.

Identity-bearing citation metadata should be added only after the anonymous review period ends.
