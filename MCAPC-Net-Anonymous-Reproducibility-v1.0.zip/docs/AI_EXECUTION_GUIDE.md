# AI Execution Guide

This guide defines the permitted execution order, validation gates, and interpretation rules for an automated coding agent.

## Nonnegotiable boundaries

1. Do not alter `configs/main.yaml` during the main run.
2. Do not use D1 or F1 outcomes in fitting, preprocessing, alpha selection, epoch selection, or parameter updating.
3. Fit every imputer, scaler, market calibrator, and predictive baseline inside its training window.
4. Preserve the class order `H, D, A` in every probability matrix.
5. Preserve the source order `AvgClose, B365Close, AvgOpen, B365Open`.
6. Write computed records only under `results/computed/`, `artifacts/models/`, `artifacts/predictions/`, and `logs/full_run.log`.
7. Never copy values from `results/reference_targets/` into computed outputs.

## Command sequence

From the repository root:

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python -m pip install -e .
bash scripts/run_checks.sh
bash scripts/run_full.sh
```

## Gate 1: source registration

Confirm that `data/raw/source_manifest.json` contains five entries, nonzero byte counts, SHA-256 digests, and row counts of 380, 380, 380, 306, and 306 for E0, SP1, I1, D1, and F1. A row-count mismatch is a hard stop.

## Gate 2: predictor construction

Confirm that `data/processed/feature_registry.json` contains exactly 112 ordered names. The first fixture in each team history must have missing historical-form values before fold-local imputation. Later fixtures may use only records dated earlier than the current fixture.

## Gate 3: temporal partitions

Confirm five outer training sizes of 190, 380, 570, 760, and 950 and five validation sizes of 190. For each fold, the largest training index must be smaller than the smallest validation index.

## Gate 4: inner selection

Evaluate residual coefficients `0`, `0.005`, `0.01`, `0.02`, and `0.05` on the latest 20% of each outer training window. Select the minimum inner-validation RPS and record the selected epoch. Refit on the full outer training window for the fixed epoch count before touching the outer validation block.

## Gate 5: frozen transfer

Fit preprocessing and SMTBCM on all 1,140 development matches. Train the five registered seeds for the fixed duration. Use the arithmetic mean of the three learned development-league embeddings for D1 and F1. Average seed-level probabilities before computing the combined held-out metrics.

## Gate 6: inference and diagnostics

Run league-stratified bootstrap inference with 10,000 resamples. Apply the Holm adjustment only to the two prespecified comparisons against FR-MCCM and Bet365 closing probabilities. Record stacking as a secondary comparison without adding it to that family. Run the architecture, feature-group, capacity, learning-curve, calibration, correction-magnitude, perturbation, and fixed-rule decision diagnostics.

## Completion conditions

The run is complete only when:

- unit checks pass, with no skipped check after the locked environment is installed;
- all five outer folds finish;
- all five final seeds finish;
- every probability row is finite, strictly positive after numerical clipping, and sums to one within `1e-6`;
- `python -m mcapc.cli audit --config configs/main.yaml --require-computed` returns `PASS`;
- `MANIFEST.sha256` is regenerated after the last output is written.

Reference targets are comparison aids, not evidence of execution. Any difference from a reference value must be retained and investigated through data digests, dependency versions, fold boundaries, convergence records, and seed states; it must not be overwritten.
