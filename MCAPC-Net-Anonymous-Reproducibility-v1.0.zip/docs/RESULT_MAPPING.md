# Result Traceability

| Manuscript output | Producing stage | Repository output |
|---|---|---|
| Table 9 fold boundaries | preparation | `results/computed/fold_boundaries.csv` |
| Table 10 baseline settings | fixed configuration | `configs/main.yaml` |
| Table 11 development comparison | outer validation | `results/computed/development_summary.csv` |
| Table 12 seed stability | final seed fits | `results/computed/seed_stability.csv` |
| Tables 14 and 15 architecture ablation | ablation runner | `results/computed/architecture_ablation.csv` |
| Table 16 alpha sensitivity | inner validation | `results/computed/alpha_selection.csv` |
| Tables 17 and 22 held-out comparison | frozen evaluation | `results/computed/heldout_metrics.csv` |
| Table 20 paired inference | bootstrap analysis | `results/computed/paired_bootstrap.csv` |
| Table 21 attention weights | prediction diagnostics | `results/computed/attention_summary.csv` |
| Table 23 feature ablation | ablation runner | `results/computed/feature_ablation.csv` |
| Tables 24 and 25 capacity diagnostics | capacity runner | `results/computed/capacity_diagnostics.csv` |
| Table 26 calibration sensitivity | calibration analysis | `results/computed/calibration_sensitivity.csv` |
| Table 27 residual magnitude | residual analysis | `results/computed/residual_diagnostics.csv` |
| Tables 28 and 29 decision analysis | decision runner | `results/computed/decision_analysis.csv` |
| Table 30 fold-level RPS | outer validation | `results/computed/development_fold_metrics.csv` |
| Table 31 alpha trace | inner validation | `results/computed/alpha_selection.csv` |
| Tables 32 and 37 fold uncertainty | uncertainty analysis | `results/computed/development_summary.csv` |
| Tables 33, 34, and 36 held-out intervals | bootstrap analysis | `results/computed/comparator_uncertainty.csv` |
| Table 35 held-out conventional baselines | frozen evaluation | `results/computed/heldout_metrics.csv` |

Every completed run also writes match-level probability files, a configuration digest, a source-data digest, package versions, seed states, and model checkpoints.
