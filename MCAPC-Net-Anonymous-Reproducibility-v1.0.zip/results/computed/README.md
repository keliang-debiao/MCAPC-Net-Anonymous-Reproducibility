# Computed result directory

Files in this directory are created only by a completed local execution. Reference targets are stored separately and are never imported by the computational pipeline.
