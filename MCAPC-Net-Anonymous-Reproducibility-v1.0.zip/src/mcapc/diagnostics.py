"""Ablation, capacity, learning-curve, and perturbation diagnostics."""

from __future__ import annotations

import copy
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from sklearn.impute import SimpleImputer
from sklearn.neural_network import MLPClassifier
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

from .analysis import feature_groups
from .calibration import SMTBCM
from .metrics import evaluate_probabilities, ranked_probability_score
from .model import trainable_parameter_count
from .training import FoldPreprocessor, predict_network, train_network


def _fit_network_variant(
    x_train: np.ndarray,
    market_train: np.ndarray,
    teacher_train: np.ndarray,
    league_train: np.ndarray,
    y_train: np.ndarray,
    x_validation: np.ndarray,
    market_validation: np.ndarray,
    teacher_validation: np.ndarray,
    league_validation: np.ndarray,
    y_validation: np.ndarray,
    cfg: dict[str, Any],
    seed: int,
    epochs: int,
    overrides: dict[str, Any] | None = None,
) -> tuple[dict[str, np.ndarray], int]:
    model, _ = train_network(
        x_train,
        market_train,
        teacher_train,
        league_train,
        y_train,
        x_validation,
        market_validation,
        teacher_validation,
        league_validation,
        y_validation,
        cfg,
        seed,
        float(cfg["model"]["selected_alpha"]),
        fixed_epochs=epochs,
        model_overrides=overrides,
    )
    return predict_network(model, x_validation, market_validation, teacher_validation, league_validation), trainable_parameter_count(model)


def _source_selection(market: np.ndarray, indices: tuple[int, ...]) -> np.ndarray:
    selected = market[:, indices, :]
    repetitions = [selected[:, index % len(indices), :] for index in range(4)]
    return np.stack(repetitions, axis=1)


def run_diagnostics(
    x_development_raw: np.ndarray,
    y_development: np.ndarray,
    market_development: np.ndarray,
    league_development: np.ndarray,
    x_heldout_raw: np.ndarray,
    y_heldout: np.ndarray,
    market_heldout: np.ndarray,
    feature_names: list[str],
    full_prediction: np.ndarray,
    cfg: dict[str, Any],
    final_epoch: int,
    result_dir: Path,
) -> None:
    seed = int(cfg["validation"]["seeds"][0])
    preprocessing = FoldPreprocessor.fit(x_development_raw)
    x_development = preprocessing.transform(x_development_raw)
    x_heldout = preprocessing.transform(x_heldout_raw)
    teacher = SMTBCM().fit(market_development, y_development)
    teacher_development = teacher.predict_proba(market_development)
    teacher_heldout = teacher.predict_proba(market_heldout)
    transfer = np.full(len(y_heldout), -1, dtype=int)

    architecture_rows: list[dict[str, Any]] = [{"variant": "CompleteSeedEnsemble", **evaluate_probabilities(y_heldout, full_prediction)}]
    for name, overrides, train_league in (
        ("WithoutPrototypeAssistance", {"use_prototypes": False}, league_development),
        ("UniformMarketAttention", {"use_attention": False}, league_development),
        ("WithoutScalarGate", {"use_gate": False}, league_development),
        ("WithoutLeagueConditioning", {}, np.full(len(league_development), -1, dtype=int)),
    ):
        output, parameters = _fit_network_variant(
            x_development,
            market_development,
            teacher_development,
            train_league,
            y_development,
            x_heldout,
            market_heldout,
            teacher_heldout,
            transfer,
            y_heldout,
            cfg,
            seed,
            final_epoch,
            overrides,
        )
        architecture_rows.append({"variant": name, "trainable_parameters": parameters, **evaluate_probabilities(y_heldout, output["probabilities"])})
    architecture_rows.append({"variant": "SMTBCMTeacherOnly", **evaluate_probabilities(y_heldout, teacher_heldout)})
    architecture_rows.append({"variant": "MarketB365Close", **evaluate_probabilities(y_heldout, market_heldout[:, 1, :])})
    pd.DataFrame(architecture_rows).to_csv(result_dir / "architecture_ablation.csv", index=False)

    group_registry = feature_groups(feature_names)
    feature_rows: list[dict[str, Any]] = [{"configuration": "FullMCAPC-Net", **evaluate_probabilities(y_heldout, full_prediction)}]
    configurations = [
        ("WithoutCalendarVariables", group_registry["calendar"], market_development, market_heldout),
        ("WithoutUncertaintyVariables", group_registry["market_uncertainty"], market_development, market_heldout),
        ("WithoutHistoricalForm", group_registry["history"], market_development, market_heldout),
        ("WithoutMarketDerivedNumericalFeatures", group_registry["market"], market_development, market_heldout),
    ]
    for name, removed, train_market, heldout_market in configurations:
        altered_train = x_development.copy()
        altered_heldout = x_heldout.copy()
        altered_train[:, removed] = 0.0
        altered_heldout[:, removed] = 0.0
        local_teacher = SMTBCM().fit(train_market, y_development)
        output, _ = _fit_network_variant(
            altered_train,
            train_market,
            local_teacher.predict_proba(train_market),
            league_development,
            y_development,
            altered_heldout,
            heldout_market,
            local_teacher.predict_proba(heldout_market),
            transfer,
            y_heldout,
            cfg,
            seed,
            final_epoch,
        )
        feature_rows.append({"configuration": name, **evaluate_probabilities(y_heldout, output["probabilities"])})
    for name, sources in (("ClosingMarketSourcesOnly", (0, 1)), ("OpeningMarketSourcesOnly", (2, 3)), ("Bet365SourceOnly", (1,))):
        train_market = _source_selection(market_development, sources)
        heldout_market = _source_selection(market_heldout, sources)
        local_teacher = SMTBCM().fit(train_market, y_development)
        output, _ = _fit_network_variant(
            x_development,
            train_market,
            local_teacher.predict_proba(train_market),
            league_development,
            y_development,
            x_heldout,
            heldout_market,
            local_teacher.predict_proba(heldout_market),
            transfer,
            y_heldout,
            cfg,
            seed,
            final_epoch,
        )
        feature_rows.append({"configuration": name, **evaluate_probabilities(y_heldout, output["probabilities"])})
    nonmarket = sorted(set(range(len(feature_names))).difference(group_registry["market"]))
    nonmarket_model = Pipeline(
        [
            ("imputer", SimpleImputer(strategy="median")),
            ("scaler", StandardScaler()),
            ("classifier", MLPClassifier(hidden_layer_sizes=(72,), max_iter=600, early_stopping=True, random_state=seed)),
        ]
    )
    nonmarket_model.fit(x_development_raw[:, nonmarket], y_development)
    nonmarket_prediction = nonmarket_model.predict_proba(x_heldout_raw[:, nonmarket])
    feature_rows.append({"configuration": "NonMarketMultilayerPerceptron", **evaluate_probabilities(y_heldout, nonmarket_prediction)})
    feature_frame = pd.DataFrame(feature_rows)
    feature_frame["rps_change"] = feature_frame["rps"] - float(feature_frame.loc[0, "rps"])
    feature_frame.to_csv(result_dir / "feature_ablation.csv", index=False)

    capacity_rows: list[dict[str, Any]] = []
    for dimension in (24, 48, 72, 96):
        capacity_cfg = copy.deepcopy(cfg)
        capacity_cfg["model"]["hidden_dimension"] = dimension
        output, parameters = _fit_network_variant(
            x_development,
            market_development,
            teacher_development,
            league_development,
            y_development,
            x_heldout,
            market_heldout,
            teacher_heldout,
            transfer,
            y_heldout,
            capacity_cfg,
            seed,
            final_epoch,
        )
        capacity_rows.append({"hidden_dimension": dimension, "trainable_parameters": parameters, **evaluate_probabilities(y_heldout, output["probabilities"])})
    pd.DataFrame(capacity_rows).to_csv(result_dir / "capacity_diagnostics.csv", index=False)

    validation = np.arange(950, 1140)
    curve_rows: list[dict[str, Any]] = []
    for training_size in (190, 380, 570, 760, 950):
        train = np.arange(training_size)
        local_preprocessing = FoldPreprocessor.fit(x_development_raw[train])
        local_train = local_preprocessing.transform(x_development_raw[train])
        local_validation = local_preprocessing.transform(x_development_raw[validation])
        local_teacher = SMTBCM().fit(market_development[train], y_development[train])
        training_scores: list[float] = []
        validation_scores: list[float] = []
        for local_seed in cfg["validation"]["seeds"]:
            model, _ = train_network(
                local_train,
                market_development[train],
                local_teacher.predict_proba(market_development[train]),
                league_development[train],
                y_development[train],
                local_validation,
                market_development[validation],
                local_teacher.predict_proba(market_development[validation]),
                league_development[validation],
                y_development[validation],
                cfg,
                int(local_seed),
                float(cfg["model"]["selected_alpha"]),
                fixed_epochs=final_epoch,
            )
            training_prediction = predict_network(model, local_train, market_development[train], local_teacher.predict_proba(market_development[train]), league_development[train])["probabilities"]
            validation_prediction = predict_network(model, local_validation, market_development[validation], local_teacher.predict_proba(market_development[validation]), league_development[validation])["probabilities"]
            training_scores.append(ranked_probability_score(y_development[train], training_prediction))
            validation_scores.append(ranked_probability_score(y_development[validation], validation_prediction))
        curve_rows.append(
            {
                "training_matches": training_size,
                "training_rps": float(np.mean(training_scores)),
                "validation_rps_mean": float(np.mean(validation_scores)),
                "validation_rps_sd": float(np.std(validation_scores, ddof=1)),
                "train_validation_gap": float(np.mean(validation_scores) - np.mean(training_scores)),
            }
        )
    pd.DataFrame(curve_rows).to_csv(result_dir / "learning_curve.csv", index=False)

    generator = np.random.default_rng(seed)
    noise_rows: list[dict[str, Any]] = []
    base_logit = np.log(np.clip(full_prediction, 1.0e-12, None))
    for level in cfg["inference"]["noise_levels"]:
        repetitions = 1 if float(level) == 0.0 else int(cfg["inference"]["noise_repetitions"])
        scores = []
        for _ in range(repetitions):
            disturbed = base_logit + generator.normal(0.0, float(level), size=base_logit.shape)
            disturbed -= disturbed.max(axis=1, keepdims=True)
            prediction = np.exp(disturbed)
            prediction /= prediction.sum(axis=1, keepdims=True)
            scores.append(ranked_probability_score(y_heldout, prediction))
        noise_rows.append({"noise_sd": float(level), "repetitions": repetitions, "rps_mean": float(np.mean(scores)), "rps_sd": float(np.std(scores, ddof=1)) if len(scores) > 1 else 0.0})
    pd.DataFrame(noise_rows).to_csv(result_dir / "logit_noise_stress.csv", index=False)
