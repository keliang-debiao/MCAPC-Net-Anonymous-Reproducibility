"""Public data retrieval, validation, and source registration."""

from __future__ import annotations

import hashlib
import json
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import pandas as pd

from .config import resolve_path


REQUIRED_MATCH_COLUMNS = {"Date", "HomeTeam", "AwayTeam", "FTHG", "FTAG", "FTR"}


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _download(url: str, destination: Path) -> None:
    request = urllib.request.Request(url, headers={"User-Agent": "MCAPC-Net-Reproducibility/1.0"})
    with urllib.request.urlopen(request, timeout=90) as response, destination.open("wb") as stream:
        while True:
            block = response.read(1024 * 1024)
            if not block:
                break
            stream.write(block)


def read_source_csv(path: Path) -> pd.DataFrame:
    last_error: Exception | None = None
    for encoding in ("utf-8-sig", "utf-8", "latin-1"):
        try:
            return pd.read_csv(path, encoding=encoding)
        except UnicodeDecodeError as exc:
            last_error = exc
    if last_error is not None:
        raise last_error
    raise RuntimeError(f"Unable to read {path}")


def download_sources(cfg: dict[str, Any], force: bool = False) -> dict[str, Any]:
    raw_dir = resolve_path(cfg, "raw_dir")
    raw_dir.mkdir(parents=True, exist_ok=True)
    records: list[dict[str, Any]] = []
    for league, filename in cfg["data"]["files"].items():
        destination = raw_dir / filename
        url = f"{cfg['data']['base_url'].rstrip('/')}/{filename}"
        if force or not destination.exists():
            _download(url, destination)
        frame = read_source_csv(destination)
        records.append(
            {
                "league": league,
                "filename": filename,
                "url": url,
                "retrieved_at_utc": datetime.now(timezone.utc).isoformat(),
                "bytes": destination.stat().st_size,
                "rows": int(len(frame)),
                "sha256": sha256_file(destination),
            }
        )
    manifest = {
        "provider": "Football-Data.co.uk",
        "season": cfg["study"]["season"],
        "files": records,
    }
    manifest_path = raw_dir / "source_manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2, sort_keys=True), encoding="utf-8")
    return manifest


def _parse_dates(series: pd.Series, preferred_format: str) -> pd.Series:
    parsed = pd.to_datetime(series, format=preferred_format, errors="coerce", dayfirst=True)
    if parsed.isna().any():
        fallback = pd.to_datetime(series, errors="coerce", dayfirst=True)
        parsed = parsed.fillna(fallback)
    return parsed


def load_raw_matches(cfg: dict[str, Any]) -> pd.DataFrame:
    raw_dir = resolve_path(cfg, "raw_dir")
    frames: list[pd.DataFrame] = []
    odds_columns = {column for columns in cfg["data"]["source_columns"].values() for column in columns}
    for league, filename in cfg["data"]["files"].items():
        path = raw_dir / filename
        if not path.exists():
            raise FileNotFoundError(f"Missing source file: {path}. Run the download stage first.")
        frame = read_source_csv(path)
        required = REQUIRED_MATCH_COLUMNS.union(odds_columns)
        missing = required.difference(frame.columns)
        if missing:
            raise ValueError(f"{league} is missing required columns: {sorted(missing)}")
        expected = int(cfg["study"]["expected_matches"][league])
        if len(frame) != expected:
            raise ValueError(f"{league} row count is {len(frame)}, expected {expected}")
        frame = frame.copy()
        frame["League"] = league
        frame["SourceRow"] = range(len(frame))
        frame["MatchDate"] = _parse_dates(frame[cfg["data"]["date_column"]], cfg["data"]["date_format"])
        if frame["MatchDate"].isna().any():
            raise ValueError(f"{league} contains unparsed dates")
        frames.append(frame)
    combined = pd.concat(frames, ignore_index=True)
    return combined.sort_values(["MatchDate", "League", "SourceRow"], kind="mergesort").reset_index(drop=True)
