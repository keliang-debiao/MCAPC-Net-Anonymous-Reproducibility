"""Post-estimation analyses used by the manuscript tables."""

from __future__ import annotations

from typing import Iterable

import numpy as np
import pandas as pd

from .metrics import calibration_error, decision_value, normalize_probabilities, per_match_rps, stratified_bootstrap_indices


def calibration_sensitivity(y: np.ndarray, probabilities: np.ndarray) -> pd.DataFrame:
    rows: list[dict[str, float | str | int]] = []
    for bins in (5, 10, 15, 20):
        ece, mce = calibration_error(y, probabilities, bins=bins, equal_frequency=False)
        rows.append({"binning": "equal_width", "bins": bins, "ece": ece, "mce": mce})
    ece, mce = calibration_error(y, probabilities, bins=15, equal_frequency=True)
    rows.append({"binning": "equal_frequency", "bins": 15, "ece": ece, "mce": mce})
    return pd.DataFrame(rows)


def residual_diagnostics(
    y: np.ndarray,
    teacher: np.ndarray,
    final: np.ndarray,
    correction: np.ndarray,
) -> pd.DataFrame:
    teacher = normalize_probabilities(teacher)
    final = normalize_probabilities(final)
    correction = np.asarray(correction, dtype=float)
    norms = np.linalg.norm(correction, axis=1)
    delta = per_match_rps(y, final) - per_match_rps(y, teacher)
    tolerance = 1.0e-12
    row = {
        "mean_logit_norm": float(norms.mean()),
        "median_logit_norm": float(np.median(norms)),
        "p95_logit_norm": float(np.quantile(norms, 0.95)),
        "maximum_logit_norm": float(norms.max()),
        "mean_probability_l1": float(np.abs(final - teacher).sum(axis=1).mean()),
        "rps_improved": int(np.sum(delta < -tolerance)),
        "rps_worsened": int(np.sum(delta > tolerance)),
        "rps_unchanged": int(np.sum(np.abs(delta) <= tolerance)),
        "top_class_changed": int(np.sum(final.argmax(axis=1) != teacher.argmax(axis=1))),
        "top_class_changed_rate": float(np.mean(final.argmax(axis=1) != teacher.argmax(axis=1))),
    }
    return pd.DataFrame([row])


def decision_table(
    y: np.ndarray,
    probabilities: np.ndarray,
    closing_odds: np.ndarray,
    thresholds: Iterable[float],
    strata: np.ndarray | None = None,
    replications: int = 0,
    seed: int = 2026,
) -> pd.DataFrame:
    rows: list[dict[str, float | int]] = []
    for threshold in thresholds:
        result = decision_value(y, probabilities, closing_odds, float(threshold))
        row: dict[str, float | int] = {"threshold": float(threshold), "decisions": result.decisions, "hit_rate": result.hit_rate, "gross_roi": result.gross_roi}
        if strata is not None and replications > 0:
            bootstrap = [decision_value(y[index], probabilities[index], closing_odds[index], float(threshold)) for index in stratified_bootstrap_indices(strata, replications, seed)]
            roi = np.array([item.gross_roi for item in bootstrap], dtype=float)
            hit_rate = np.array([item.hit_rate for item in bootstrap], dtype=float)
            decisions = np.array([item.decisions for item in bootstrap], dtype=float)
            row.update(
                {
                    "decisions_ci_lower": float(np.quantile(decisions, 0.025)),
                    "decisions_ci_upper": float(np.quantile(decisions, 0.975)),
                    "hit_rate_ci_lower": float(np.quantile(hit_rate, 0.025)),
                    "hit_rate_ci_upper": float(np.quantile(hit_rate, 0.975)),
                    "gross_roi_ci_lower": float(np.quantile(roi, 0.025)),
                    "gross_roi_ci_upper": float(np.quantile(roi, 0.975)),
                }
            )
        rows.append(row)
    return pd.DataFrame(rows)


def noise_robustness(
    model_predictor,
    numeric: np.ndarray,
    levels: Iterable[float],
    repetitions: int,
    seed: int,
) -> pd.DataFrame:
    generator = np.random.default_rng(seed)
    rows: list[dict[str, float | int]] = []
    for level in levels:
        for repetition in range(repetitions):
            disturbed = numeric + generator.normal(0.0, float(level), size=numeric.shape)
            probabilities = model_predictor(disturbed)
            rows.append(
                {
                    "noise_sd": float(level),
                    "repetition": repetition + 1,
                    "mean_max_probability": float(np.max(probabilities, axis=1).mean()),
                    "mean_probability_shift": float(np.abs(probabilities - model_predictor(numeric)).sum(axis=1).mean()),
                }
            )
    return pd.DataFrame(rows)


def feature_groups(feature_names: list[str]) -> dict[str, list[int]]:
    market_tokens = ("odds_", "implied_", "prob_", "logprob_", "overround", "entropy", "market_consensus")
    calendar_tokens = ("month_", "weekday_", "dayofyear_")
    history_tokens = ("home_", "away_")
    groups = {
        "market": [index for index, name in enumerate(feature_names) if any(token in name for token in market_tokens)],
        "calendar": [index for index, name in enumerate(feature_names) if name.startswith(calendar_tokens)],
        "history": [index for index, name in enumerate(feature_names) if name.startswith(history_tokens)],
    }
    groups["market_uncertainty"] = [index for index, name in enumerate(feature_names) if "overround" in name or "entropy" in name]
    return groups
