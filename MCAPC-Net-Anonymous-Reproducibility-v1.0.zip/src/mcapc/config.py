"""Configuration loading, validation, and hashing."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

import yaml


def repository_root() -> Path:
    return Path(__file__).resolve().parents[2]


def load_config(path: str | Path) -> dict[str, Any]:
    path = Path(path).resolve()
    with path.open("r", encoding="utf-8") as stream:
        cfg = yaml.safe_load(stream)
    if not isinstance(cfg, dict):
        raise ValueError("Configuration root must be a mapping")
    cfg["_config_path"] = str(path)
    cfg["_root"] = str(path.parents[1])
    validate_config(cfg)
    return cfg


def validate_config(cfg: dict[str, Any]) -> None:
    required = {"study", "paths", "data", "features", "validation", "model", "inference", "baselines"}
    missing = required.difference(cfg)
    if missing:
        raise ValueError(f"Missing configuration sections: {sorted(missing)}")
    if cfg["features"]["total_count"] != 112:
        raise ValueError("The fixed predictor count must be 112")
    if cfg["validation"]["outer_folds"] != 5:
        raise ValueError("The fixed outer-fold count must be five")
    if cfg["validation"]["seeds"] != [2026, 2027, 2028, 2029, 2030]:
        raise ValueError("Unexpected seed registry")
    dev = set(cfg["study"]["development_leagues"])
    held = set(cfg["study"]["heldout_leagues"])
    if dev.intersection(held):
        raise ValueError("Development and held-out leagues must be disjoint")
    if cfg["study"]["class_order"] != ["H", "D", "A"]:
        raise ValueError("Class order must remain H, D, A")


def resolve_path(cfg: dict[str, Any], key: str) -> Path:
    root = Path(cfg["_root"])
    return (root / cfg["paths"][key]).resolve()


def config_digest(cfg: dict[str, Any]) -> str:
    stable = {k: v for k, v in cfg.items() if not k.startswith("_")}
    payload = json.dumps(stable, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()
