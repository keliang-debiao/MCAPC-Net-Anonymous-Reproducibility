"""Command-line entry points for the reproducibility workflow."""

from __future__ import annotations

import argparse
import json
import logging
from pathlib import Path

from .audit import audit_repository, write_manifest
from .config import load_config
from .data import download_sources
from .features import prepare_data
from .pipeline import run_experiment


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="mcapc", description="MCAPC-Net reproducibility workflow")
    subcommands = parser.add_subparsers(dest="command", required=True)
    for command in ("download", "prepare", "run", "audit"):
        child = subcommands.add_parser(command)
        child.add_argument("--config", default="configs/main.yaml")
        if command == "audit":
            child.add_argument("--require-computed", action="store_true")
    return parser


def _configure_logging(path: Path | None) -> None:
    handlers: list[logging.Handler] = [logging.StreamHandler()]
    if path is not None:
        path.parent.mkdir(parents=True, exist_ok=True)
        handlers.append(logging.FileHandler(path, mode="a", encoding="utf-8"))
    logging.basicConfig(level=logging.INFO, format="%(asctime)sZ | %(levelname)s | %(message)s", datefmt="%Y-%m-%dT%H:%M:%S", handlers=handlers)


def main() -> int:
    arguments = _parser().parse_args()
    cfg = load_config(arguments.config)
    root = Path(cfg["_root"])
    if arguments.command == "audit":
        _configure_logging(None)
        result = audit_repository(root, require_computed=arguments.require_computed)
        print(json.dumps(result, indent=2))
        if result["status"] == "PASS":
            write_manifest(root, root / "MANIFEST.sha256")
            return 0
        return 1
    log_path = root / cfg["paths"]["log_file"]
    _configure_logging(log_path)
    if arguments.command == "download":
        outputs = download_sources(cfg)
    elif arguments.command == "prepare":
        outputs = prepare_data(cfg)
    else:
        outputs = run_experiment(cfg)
    logging.getLogger("mcapc").info("stage=%s status=completed outputs=%s", arguments.command, outputs)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
