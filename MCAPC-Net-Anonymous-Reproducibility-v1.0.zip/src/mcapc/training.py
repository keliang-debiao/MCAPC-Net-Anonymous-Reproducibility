"""Deterministic preprocessing, training, and inference routines."""

from __future__ import annotations

import copy
import random
from dataclasses import dataclass
from typing import Any

import numpy as np
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler

from .metrics import ranked_probability_score
from .model import MCAPCNet, composite_loss, require_torch


@dataclass
class FoldPreprocessor:
    imputer: SimpleImputer
    scaler: StandardScaler

    @classmethod
    def fit(cls, values: np.ndarray) -> "FoldPreprocessor":
        imputer = SimpleImputer(strategy="median", add_indicator=False)
        scaler = StandardScaler()
        scaler.fit(imputer.fit_transform(values))
        return cls(imputer=imputer, scaler=scaler)

    def transform(self, values: np.ndarray) -> np.ndarray:
        transformed = self.scaler.transform(self.imputer.transform(values))
        return np.asarray(transformed, dtype=np.float32)


def set_deterministic_seed(seed: int) -> None:
    require_torch()
    import torch

    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.use_deterministic_algorithms(True, warn_only=True)


def _tensor_bundle(x: np.ndarray, market: np.ndarray, teacher: np.ndarray, league: np.ndarray, y: np.ndarray | None = None) -> tuple[Any, ...]:
    import torch

    output: list[Any] = [
        torch.as_tensor(x, dtype=torch.float32),
        torch.as_tensor(market, dtype=torch.float32),
        torch.as_tensor(teacher, dtype=torch.float32),
        torch.as_tensor(league, dtype=torch.long),
    ]
    if y is not None:
        output.append(torch.as_tensor(y, dtype=torch.long))
    return tuple(output)


def predict_network(model: Any, x: np.ndarray, market: np.ndarray, teacher: np.ndarray, league: np.ndarray, batch_size: int = 512) -> dict[str, np.ndarray]:
    require_torch()
    import torch

    model.eval()
    collected: dict[str, list[np.ndarray]] = {name: [] for name in ("probabilities", "attention", "gate", "residual", "correction", "prototype_scores")}
    with torch.no_grad():
        for start in range(0, len(x), batch_size):
            stop = start + batch_size
            tensors = _tensor_bundle(x[start:stop], market[start:stop], teacher[start:stop], league[start:stop])
            output = model(*tensors)
            for name in collected:
                collected[name].append(output[name].cpu().numpy())
    return {name: np.concatenate(parts, axis=0) for name, parts in collected.items()}


def train_network(
    x_train: np.ndarray,
    market_train: np.ndarray,
    teacher_train: np.ndarray,
    league_train: np.ndarray,
    y_train: np.ndarray,
    x_validation: np.ndarray,
    market_validation: np.ndarray,
    teacher_validation: np.ndarray,
    league_validation: np.ndarray,
    y_validation: np.ndarray,
    cfg: dict[str, Any],
    seed: int,
    alpha: float,
    fixed_epochs: int | None = None,
    model_overrides: dict[str, Any] | None = None,
) -> tuple[Any, list[dict[str, float]]]:
    require_torch()
    import torch
    from torch.utils.data import DataLoader, TensorDataset

    set_deterministic_seed(seed)
    settings = cfg["model"]
    architecture = dict(model_overrides or {})
    model = MCAPCNet(
        feature_count=x_train.shape[1],
        hidden_dimension=int(settings["hidden_dimension"]),
        market_embedding_dimension=int(settings["market_embedding_dimension"]),
        league_count=len(cfg["study"]["development_leagues"]),
        league_embedding_dimension=int(settings["league_embedding_dimension"]),
        numerical_dropout=float(settings["numerical_dropout"]),
        fusion_dropout=float(settings["fusion_dropout"]),
        prototype_weight=float(settings["prototype_weight"]),
        alpha=float(alpha),
        **architecture,
    )
    dataset = TensorDataset(*_tensor_bundle(x_train, market_train, teacher_train, league_train, y_train))
    generator = torch.Generator().manual_seed(seed)
    loader = DataLoader(dataset, batch_size=int(settings["batch_size"]), shuffle=True, generator=generator, num_workers=0)
    optimizer = torch.optim.AdamW(model.parameters(), lr=float(settings["learning_rate"]), weight_decay=float(settings["weight_decay"]))
    best_state = copy.deepcopy(model.state_dict())
    best_rps = float("inf")
    stale_epochs = 0
    history: list[dict[str, float]] = []
    epoch_limit = int(fixed_epochs) if fixed_epochs is not None else int(settings["maximum_epochs"])
    for epoch in range(1, epoch_limit + 1):
        model.train()
        batch_losses: list[float] = []
        for numeric, market, teacher, league, target in loader:
            optimizer.zero_grad(set_to_none=True)
            output = model(numeric, market, teacher, league)
            loss, _ = composite_loss(output, target, teacher, settings["loss_weights"])
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), float(settings["gradient_clip"]))
            optimizer.step()
            batch_losses.append(float(loss.detach()))
        if fixed_epochs is not None:
            history.append({"epoch": float(epoch), "training_loss": float(np.mean(batch_losses)), "validation_rps": float("nan")})
            best_state = copy.deepcopy(model.state_dict())
            continue
        validation = predict_network(model, x_validation, market_validation, teacher_validation, league_validation)
        validation_rps = ranked_probability_score(y_validation, validation["probabilities"])
        history.append({"epoch": float(epoch), "training_loss": float(np.mean(batch_losses)), "validation_rps": validation_rps})
        if validation_rps < best_rps - 1.0e-7:
            best_rps = validation_rps
            best_state = copy.deepcopy(model.state_dict())
            stale_epochs = 0
        else:
            stale_epochs += 1
            if stale_epochs >= int(settings["early_stopping_patience"]):
                break
    model.load_state_dict(best_state)
    return model, history
