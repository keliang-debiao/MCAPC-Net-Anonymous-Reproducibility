"""Conventional predictive baselines with fold-local preprocessing."""

from __future__ import annotations

from typing import Any

import numpy as np
from sklearn.base import clone
from sklearn.discriminant_analysis import QuadraticDiscriminantAnalysis
from sklearn.ensemble import AdaBoostClassifier, BaggingClassifier, ExtraTreesClassifier, GradientBoostingClassifier, HistGradientBoostingClassifier, RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.neural_network import MLPClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.neighbors import KNeighborsClassifier
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier

from .metrics import normalize_probabilities


def classifier_registry(cfg: dict[str, Any], seed: int) -> dict[str, Any]:
    settings = cfg["baselines"]
    tree = DecisionTreeClassifier(max_depth=int(settings["tree_depth"]), min_samples_leaf=8, random_state=seed)
    try:
        bagging = BaggingClassifier(estimator=clone(tree), n_estimators=int(settings["bagging_estimators"]), random_state=seed, n_jobs=-1)
    except TypeError:
        bagging = BaggingClassifier(base_estimator=clone(tree), n_estimators=int(settings["bagging_estimators"]), random_state=seed, n_jobs=-1)
    registry: dict[str, Any] = {
        "LogisticL2Odds": LogisticRegression(C=float(settings["logistic_c"]), max_iter=3000, random_state=seed),
        "LogisticBalancedOdds": LogisticRegression(C=float(settings["logistic_c"]), class_weight="balanced", max_iter=3000, random_state=seed),
        "KNearestNeighborsOdds": KNeighborsClassifier(n_neighbors=int(settings["knn_neighbors"]), weights="distance"),
        "GaussianNBOdds": GaussianNB(),
        "QDAOdds": QuadraticDiscriminantAnalysis(reg_param=float(settings["qda_regularization"])),
        "SVMRBFOdds": SVC(C=1.0, gamma="scale", probability=True, random_state=seed),
        "DecisionTreeOdds": tree,
        "BaggingOdds": bagging,
        "AdaBoostOdds": AdaBoostClassifier(n_estimators=120, learning_rate=0.04, random_state=seed),
        "GradientBoostingOdds": GradientBoostingClassifier(n_estimators=160, learning_rate=0.035, max_depth=2, random_state=seed),
        "HistGradientBoostingOdds": HistGradientBoostingClassifier(max_iter=180, learning_rate=0.04, max_leaf_nodes=15, random_state=seed),
        "MLPClassifierOdds": MLPClassifier(hidden_layer_sizes=(72,), alpha=1.0e-4, learning_rate_init=7.0e-4, max_iter=600, early_stopping=True, random_state=seed),
        "RandomForestOdds": RandomForestClassifier(n_estimators=int(settings["random_forest_estimators"]), max_depth=8, min_samples_leaf=5, random_state=seed, n_jobs=-1),
        "ExtraTreesOdds": ExtraTreesClassifier(n_estimators=int(settings["extra_trees_estimators"]), max_depth=9, min_samples_leaf=4, random_state=seed, n_jobs=-1),
    }
    try:
        from xgboost import XGBClassifier

        registry["XGBoostOdds"] = XGBClassifier(
            n_estimators=int(settings["xgboost_estimators"]),
            max_depth=int(settings["xgboost_depth"]),
            learning_rate=float(settings["xgboost_learning_rate"]),
            subsample=0.85,
            colsample_bytree=0.85,
            objective="multi:softprob",
            eval_metric="mlogloss",
            random_state=seed,
            n_jobs=-1,
        )
    except ImportError:
        pass
    return registry


def _aligned_probabilities(model: Any, predictors: np.ndarray) -> np.ndarray:
    raw = model.predict_proba(predictors)
    output = np.full((len(predictors), 3), 1.0e-12, dtype=float)
    classes = model.named_steps["classifier"].classes_
    for source, cls in enumerate(classes):
        output[:, int(cls)] = raw[:, source]
    return normalize_probabilities(output)


def fit_predict_baselines(
    x_train: np.ndarray,
    y_train: np.ndarray,
    x_validation: np.ndarray,
    cfg: dict[str, Any],
    seed: int,
) -> tuple[dict[str, np.ndarray], dict[str, str]]:
    predictions: dict[str, np.ndarray] = {}
    failures: dict[str, str] = {}
    for name, classifier in classifier_registry(cfg, seed).items():
        model = Pipeline(
            [
                ("imputer", SimpleImputer(strategy="median", add_indicator=True)),
                ("scaler", StandardScaler()),
                ("classifier", classifier),
            ]
        )
        try:
            model.fit(x_train, y_train)
            predictions[name] = _aligned_probabilities(model, x_validation)
        except (ValueError, FloatingPointError, np.linalg.LinAlgError) as error:
            failures[name] = f"{type(error).__name__}: {error}"
    return predictions, failures
