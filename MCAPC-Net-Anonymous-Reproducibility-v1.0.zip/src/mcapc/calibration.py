"""Market calibration and probability-combination estimators."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy.optimize import minimize
from sklearn.isotonic import IsotonicRegression
from sklearn.linear_model import LogisticRegression

from .metrics import normalize_probabilities, ranked_probability_score


EPS = 1.0e-12


def _softmax(values: np.ndarray, axis: int = -1) -> np.ndarray:
    shifted = values - np.max(values, axis=axis, keepdims=True)
    output = np.exp(shifted)
    return output / output.sum(axis=axis, keepdims=True)


def _validate_market(probabilities: np.ndarray) -> np.ndarray:
    values = np.asarray(probabilities, dtype=float)
    if values.ndim != 3 or values.shape[1:] != (4, 3):
        raise ValueError("Market probabilities must have shape (matches, 4, 3)")
    values = np.clip(values, EPS, np.inf)
    return values / values.sum(axis=2, keepdims=True)


@dataclass
class MarketCalibration:
    """Weighted geometric pool with temperature and class-bias terms."""

    home_bias: bool = True
    fitted_: bool = False

    def _unpack(self, parameters: np.ndarray) -> tuple[np.ndarray, float, float, float]:
        weights = _softmax(parameters[:4])
        temperature = float(np.exp(parameters[4]))
        draw_bias = float(parameters[5])
        home_bias = float(parameters[6]) if self.home_bias else 0.0
        return weights, temperature, draw_bias, home_bias

    def _predict(self, market: np.ndarray, parameters: np.ndarray) -> np.ndarray:
        market = _validate_market(market)
        weights, temperature, draw_bias, home_bias = self._unpack(parameters)
        pooled = np.einsum("s,nsc->nc", weights, np.log(market))
        pooled[:, 0] += home_bias
        pooled[:, 1] += draw_bias
        return _softmax(pooled / temperature, axis=1)

    def fit(self, market: np.ndarray, y: np.ndarray) -> "MarketCalibration":
        market = _validate_market(market)
        y = np.asarray(y, dtype=int)
        parameter_count = 7 if self.home_bias else 6

        def objective(parameters: np.ndarray) -> float:
            prediction = self._predict(market, parameters)
            loss = -np.log(prediction[np.arange(len(y)), y]).mean()
            penalty = 1.0e-4 * float(np.sum(parameters**2))
            return float(loss + penalty)

        result = minimize(objective, np.zeros(parameter_count), method="L-BFGS-B", options={"maxiter": 1000, "ftol": 1.0e-12})
        if not result.success:
            raise RuntimeError(f"Market calibration did not converge: {result.message}")
        self.parameters_ = np.asarray(result.x, dtype=float)
        self.source_weights_, self.temperature_, self.draw_bias_, self.home_bias_ = self._unpack(self.parameters_)
        self.fitted_ = True
        return self

    def predict_proba(self, market: np.ndarray) -> np.ndarray:
        if not self.fitted_:
            raise RuntimeError("Market calibration has not been fitted")
        return self._predict(market, self.parameters_)


class FRMCCM(MarketCalibration):
    """Restricted market-consensus calibration without a home-bias term."""

    def __init__(self) -> None:
        super().__init__(home_bias=False)


class SMTBCM(MarketCalibration):
    """Source-mixed temperature and bias calibration model."""

    def __init__(self) -> None:
        super().__init__(home_bias=True)


class OptimizedProbabilityPool:
    """Convex arithmetic pool optimized by ranked probability score."""

    def fit(self, market: np.ndarray, y: np.ndarray) -> "OptimizedProbabilityPool":
        market = _validate_market(market)
        y = np.asarray(y, dtype=int)

        def objective(parameters: np.ndarray) -> float:
            weights = _softmax(parameters)
            return ranked_probability_score(y, np.einsum("s,nsc->nc", weights, market))

        result = minimize(objective, np.zeros(4), method="BFGS", options={"maxiter": 1000, "gtol": 1.0e-9})
        if not result.success and not np.isfinite(result.fun):
            raise RuntimeError(f"Probability pooling did not converge: {result.message}")
        self.source_weights_ = _softmax(np.asarray(result.x, dtype=float))
        return self

    def predict_proba(self, market: np.ndarray) -> np.ndarray:
        market = _validate_market(market)
        return normalize_probabilities(np.einsum("s,nsc->nc", self.source_weights_, market))


class OneVsRestPlatt:
    """Classwise logistic recalibration followed by simplex normalization."""

    def fit(self, probabilities: np.ndarray, y: np.ndarray) -> "OneVsRestPlatt":
        probabilities = normalize_probabilities(probabilities)
        y = np.asarray(y, dtype=int)
        logits = np.log(probabilities) - np.log1p(-np.clip(probabilities, EPS, 1.0 - EPS))
        self.models_ = []
        for cls in range(3):
            model = LogisticRegression(C=1.0, solver="lbfgs", max_iter=1000, random_state=2026)
            model.fit(logits[:, [cls]], (y == cls).astype(int))
            self.models_.append(model)
        return self

    def predict_proba(self, probabilities: np.ndarray) -> np.ndarray:
        probabilities = normalize_probabilities(probabilities)
        logits = np.log(probabilities) - np.log1p(-np.clip(probabilities, EPS, 1.0 - EPS))
        calibrated = np.column_stack([model.predict_proba(logits[:, [cls]])[:, 1] for cls, model in enumerate(self.models_)])
        return normalize_probabilities(calibrated)


class OneVsRestIsotonic:
    """Classwise isotonic recalibration followed by simplex normalization."""

    def fit(self, probabilities: np.ndarray, y: np.ndarray) -> "OneVsRestIsotonic":
        probabilities = normalize_probabilities(probabilities)
        y = np.asarray(y, dtype=int)
        self.models_ = []
        for cls in range(3):
            model = IsotonicRegression(out_of_bounds="clip", y_min=EPS, y_max=1.0 - EPS)
            model.fit(probabilities[:, cls], (y == cls).astype(float))
            self.models_.append(model)
        return self

    def predict_proba(self, probabilities: np.ndarray) -> np.ndarray:
        probabilities = normalize_probabilities(probabilities)
        calibrated = np.column_stack([model.predict(probabilities[:, cls]) for cls, model in enumerate(self.models_)])
        return normalize_probabilities(calibrated)


class MultinomialStacking:
    """Multinomial stacking on the four sources' log probabilities."""

    def fit(self, market: np.ndarray, y: np.ndarray) -> "MultinomialStacking":
        market = _validate_market(market)
        predictors = np.log(market).reshape(len(market), -1)
        self.model_ = LogisticRegression(C=0.4, solver="lbfgs", max_iter=2000, random_state=2026)
        self.model_.fit(predictors, np.asarray(y, dtype=int))
        return self

    def predict_proba(self, market: np.ndarray) -> np.ndarray:
        market = _validate_market(market)
        return normalize_probabilities(self.model_.predict_proba(np.log(market).reshape(len(market), -1)))
