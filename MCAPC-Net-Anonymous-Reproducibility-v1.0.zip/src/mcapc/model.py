"""MCAPC-Net architecture and composite training objective."""

from __future__ import annotations

from typing import Any

try:
    import torch
    from torch import nn
    from torch.nn import functional as functional
except ImportError:
    torch = None
    nn = None
    functional = None


def require_torch() -> None:
    if torch is None:
        raise RuntimeError("PyTorch is required for MCAPC-Net training; install requirements.txt")


if nn is not None:

    class MCAPCNet(nn.Module):
        """Market-attentive residual calibration network."""

        def __init__(
            self,
            feature_count: int = 112,
            hidden_dimension: int = 72,
            market_embedding_dimension: int = 8,
            league_count: int = 3,
            league_embedding_dimension: int = 8,
            numerical_dropout: float = 0.10,
            fusion_dropout: float = 0.08,
            prototype_weight: float = 0.15,
            alpha: float = 0.01,
            use_attention: bool = True,
            use_prototypes: bool = True,
            use_gate: bool = True,
        ) -> None:
            super().__init__()
            self.hidden_dimension = hidden_dimension
            self.prototype_weight = float(prototype_weight)
            self.alpha = float(alpha)
            self.use_attention = bool(use_attention)
            self.use_prototypes = bool(use_prototypes)
            self.use_gate = bool(use_gate)
            self.source_embedding = nn.Embedding(4, market_embedding_dimension)
            self.source_projection = nn.Sequential(
                nn.Linear(3 + market_embedding_dimension, market_embedding_dimension),
                nn.LayerNorm(market_embedding_dimension),
                nn.GELU(),
            )
            self.numerical_encoder = nn.Sequential(
                nn.Linear(feature_count, hidden_dimension),
                nn.LayerNorm(hidden_dimension),
                nn.GELU(),
                nn.Dropout(numerical_dropout),
                nn.Linear(hidden_dimension, hidden_dimension),
                nn.GELU(),
            )
            self.league_embedding = nn.Embedding(league_count, league_embedding_dimension)
            self.query_projection = nn.Linear(hidden_dimension + league_embedding_dimension, market_embedding_dimension)
            self.attention_token = nn.Linear(market_embedding_dimension, market_embedding_dimension, bias=False)
            self.attention_query = nn.Linear(market_embedding_dimension, market_embedding_dimension, bias=False)
            self.attention_bias = nn.Parameter(torch.zeros(market_embedding_dimension))
            self.attention_vector = nn.Parameter(torch.empty(market_embedding_dimension))
            nn.init.normal_(self.attention_vector, std=0.05)
            fusion_width = hidden_dimension + market_embedding_dimension + league_embedding_dimension + 3
            self.fusion = nn.Sequential(
                nn.Linear(fusion_width, hidden_dimension),
                nn.LayerNorm(hidden_dimension),
                nn.GELU(),
                nn.Dropout(fusion_dropout),
                nn.Linear(hidden_dimension, hidden_dimension),
                nn.GELU(),
            )
            self.prototype_bank = nn.Parameter(torch.empty(3, hidden_dimension))
            nn.init.normal_(self.prototype_bank, std=0.05)
            self.residual_head = nn.Linear(hidden_dimension, 3)
            self.gate_head = nn.Linear(hidden_dimension, 1)

        def _league_context(self, league_index: "torch.Tensor") -> "torch.Tensor":
            known = league_index >= 0
            safe_index = league_index.clamp(min=0)
            context = self.league_embedding(safe_index)
            transfer_context = self.league_embedding.weight.mean(dim=0, keepdim=True).expand_as(context)
            return torch.where(known.unsqueeze(1), context, transfer_context)

        def forward(
            self,
            numeric: "torch.Tensor",
            market_probabilities: "torch.Tensor",
            teacher_probabilities: "torch.Tensor",
            league_index: "torch.Tensor",
        ) -> dict[str, "torch.Tensor"]:
            log_market = torch.log(market_probabilities.clamp_min(1.0e-8))
            source_ids = torch.arange(4, device=numeric.device)
            source_embedding = self.source_embedding(source_ids).unsqueeze(0).expand(len(numeric), -1, -1)
            tokens = self.source_projection(torch.cat([log_market, source_embedding], dim=2))
            numeric_context = self.numerical_encoder(numeric)
            league_context = self._league_context(league_index)
            query = self.query_projection(torch.cat([numeric_context, league_context], dim=1))
            energy = torch.tanh(self.attention_token(tokens) + self.attention_query(query).unsqueeze(1) + self.attention_bias)
            learned_attention = torch.softmax(torch.einsum("nse,e->ns", energy, self.attention_vector), dim=1)
            attention = learned_attention if self.use_attention else torch.full_like(learned_attention, 0.25)
            market_context = torch.einsum("ns,nse->ne", attention, tokens)
            attended_log_probability = torch.einsum("ns,nsc->nc", attention, log_market)
            attended_probability = torch.softmax(attended_log_probability, dim=1)
            fused = self.fusion(torch.cat([numeric_context, market_context, league_context, attended_probability], dim=1))
            prototype_scores = fused @ self.prototype_bank.T
            prototype_term = self.prototype_weight * prototype_scores if self.use_prototypes else torch.zeros_like(prototype_scores)
            residual = torch.tanh(self.residual_head(fused) + prototype_term)
            gate = torch.sigmoid(self.gate_head(fused)) if self.use_gate else torch.ones((len(fused), 1), device=fused.device)
            correction = self.alpha * gate * residual
            logits = torch.log(teacher_probabilities.clamp_min(1.0e-8)) + correction
            probabilities = torch.softmax(logits, dim=1)
            return {
                "probabilities": probabilities,
                "logits": logits,
                "attention": attention,
                "gate": gate,
                "residual": residual,
                "correction": correction,
                "prototype_scores": prototype_scores,
            }

else:

    class MCAPCNet:  # type: ignore[no-redef]
        def __init__(self, *_: Any, **__: Any) -> None:
            require_torch()


def composite_loss(
    output: dict[str, "torch.Tensor"],
    target: "torch.Tensor",
    teacher: "torch.Tensor",
    weights: dict[str, float],
) -> tuple["torch.Tensor", dict[str, float]]:
    require_torch()
    probability = output["probabilities"]
    one_hot = functional.one_hot(target, num_classes=3).float()
    cumulative_p = torch.cumsum(probability, dim=1)[:, :-1]
    cumulative_y = torch.cumsum(one_hot, dim=1)[:, :-1]
    ce = functional.nll_loss(torch.log(probability.clamp_min(1.0e-8)), target)
    rps = torch.mean(torch.sum((cumulative_p - cumulative_y) ** 2, dim=1) / 2.0)
    teacher_kl = functional.kl_div(torch.log(probability.clamp_min(1.0e-8)), teacher, reduction="batchmean")
    teacher_logits = torch.log(teacher.clamp_min(1.0e-8))
    anchor = torch.mean((output["logits"] - teacher_logits) ** 2)
    attention = output["attention"]
    attention_regularizer = torch.mean(torch.sum(attention * torch.log(attention.clamp_min(1.0e-8)), dim=1))
    total = (
        float(weights["cross_entropy"]) * ce
        + float(weights["rps"]) * rps
        + float(weights["teacher_kl"]) * teacher_kl
        + float(weights["anchor"]) * anchor
        + float(weights["attention"]) * attention_regularizer
    )
    components = {
        "cross_entropy": float(ce.detach().cpu()),
        "rps": float(rps.detach().cpu()),
        "teacher_kl": float(teacher_kl.detach().cpu()),
        "anchor": float(anchor.detach().cpu()),
        "attention_regularizer": float(attention_regularizer.detach().cpu()),
        "total": float(total.detach().cpu()),
    }
    return total, components


def trainable_parameter_count(model: "nn.Module") -> int:
    require_torch()
    return int(sum(parameter.numel() for parameter in model.parameters() if parameter.requires_grad))
