"""Leakage-controlled construction of the fixed 112-variable predictor matrix."""

from __future__ import annotations

import json
from collections import defaultdict
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from .config import resolve_path


CLASS_ORDER = ("H", "D", "A")
SOURCE_ORDER = ("AvgClose", "B365Close", "AvgOpen", "B365Open")


def _market_vector(row: pd.Series, cfg: dict[str, Any]) -> tuple[dict[str, float], np.ndarray]:
    eps = float(cfg["features"]["epsilon"])
    features: dict[str, float] = {}
    probabilities: list[np.ndarray] = []
    overrounds: list[float] = []
    source_cache: list[tuple[str, np.ndarray, np.ndarray, np.ndarray, float, float]] = []
    for source in SOURCE_ORDER:
        columns = cfg["data"]["source_columns"][source]
        odds = pd.to_numeric(row[list(columns)], errors="coerce").to_numpy(dtype=float)
        odds[(odds <= 1.0) | ~np.isfinite(odds)] = np.nan
        implied = 1.0 / odds
        total = np.nansum(implied)
        if not np.isfinite(total) or total <= 0:
            probability = np.full(3, np.nan)
            overround = np.nan
            entropy = np.nan
        else:
            probability = implied / total
            overround = total - 1.0
            entropy = -float(np.nansum(probability * np.log(probability + eps)))
        source_cache.append((source, odds, implied, probability, overround, entropy))
        probabilities.append(probability)
        overrounds.append(overround)

    for source, odds, implied, probability, overround, entropy in source_cache:
        for idx, cls in enumerate(CLASS_ORDER):
            features[f"{source}_odds_{cls}"] = float(odds[idx])
        for idx, cls in enumerate(CLASS_ORDER):
            features[f"{source}_implied_{cls}"] = float(implied[idx])
        for idx, cls in enumerate(CLASS_ORDER):
            features[f"{source}_prob_{cls}"] = float(probability[idx])
        for idx, cls in enumerate(CLASS_ORDER):
            value = probability[idx]
            features[f"{source}_logprob_{cls}"] = float(np.log(value + eps)) if np.isfinite(value) else np.nan
        features[f"{source}_overround"] = float(overround)
        features[f"{source}_entropy"] = float(entropy)

    probability_matrix = np.stack(probabilities, axis=0)
    consensus = np.nanmean(probability_matrix, axis=0)
    for idx, cls in enumerate(CLASS_ORDER):
        features[f"market_consensus_prob_{cls}"] = float(consensus[idx])
    features["market_mean_overround"] = float(np.nanmean(overrounds))
    if len(features) != 60:
        raise AssertionError(f"Market feature count is {len(features)}, expected 60")
    return features, probability_matrix


def _calendar_vector(match_date: pd.Timestamp) -> dict[str, float]:
    month_angle = 2.0 * np.pi * (match_date.month - 1) / 12.0
    weekday_angle = 2.0 * np.pi * match_date.dayofweek / 7.0
    year_days = 366.0 if match_date.is_leap_year else 365.0
    year_angle = 2.0 * np.pi * (match_date.dayofyear - 1) / year_days
    return {
        "month_sin": float(np.sin(month_angle)),
        "month_cos": float(np.cos(month_angle)),
        "weekday_sin": float(np.sin(weekday_angle)),
        "weekday_cos": float(np.cos(weekday_angle)),
        "dayofyear_sin": float(np.sin(year_angle)),
        "dayofyear_cos": float(np.cos(year_angle)),
    }


def _history_vector(records: list[dict[str, float]], date: pd.Timestamp, prefix: str, windows: list[int]) -> dict[str, float]:
    output: dict[str, float] = {}
    for window in windows:
        recent = records[-window:]
        count = len(recent)
        if count == 0:
            values = {name: np.nan for name in ("ppg", "goals_for", "goals_against", "goal_difference", "win_rate", "draw_rate", "loss_rate")}
        else:
            gf = np.array([r["goals_for"] for r in recent], dtype=float)
            ga = np.array([r["goals_against"] for r in recent], dtype=float)
            pts = np.array([r["points"] for r in recent], dtype=float)
            outcomes = [r["outcome"] for r in recent]
            values = {
                "ppg": float(pts.mean()),
                "goals_for": float(gf.mean()),
                "goals_against": float(ga.mean()),
                "goal_difference": float((gf - ga).mean()),
                "win_rate": float(sum(x == "W" for x in outcomes) / count),
                "draw_rate": float(sum(x == "D" for x in outcomes) / count),
                "loss_rate": float(sum(x == "L" for x in outcomes) / count),
            }
        for name, value in values.items():
            output[f"{prefix}_{name}_{window}"] = value
    output[f"{prefix}_history_coverage"] = float(min(len(records), max(windows)) / max(windows))
    output[f"{prefix}_days_since_last"] = float((date - records[-1]["date"]).days) if records else np.nan
    if len(output) != 23:
        raise AssertionError(f"History feature count for {prefix} is {len(output)}, expected 23")
    return output


def build_features(raw: pd.DataFrame, cfg: dict[str, Any]) -> tuple[pd.DataFrame, np.ndarray]:
    windows = [int(x) for x in cfg["features"]["rolling_windows"]]
    histories: dict[tuple[str, str], list[dict[str, float]]] = defaultdict(list)
    rows: list[dict[str, Any]] = []
    market_matrices: list[np.ndarray] = []
    ordered = raw.sort_values(["MatchDate", "League", "SourceRow"], kind="mergesort")
    for _, match in ordered.iterrows():
        league = str(match["League"])
        home = str(match["HomeTeam"])
        away = str(match["AwayTeam"])
        date = pd.Timestamp(match["MatchDate"])
        home_records = histories[(league, home)]
        away_records = histories[(league, away)]

        market, probability_matrix = _market_vector(match, cfg)
        features: dict[str, Any] = {}
        features.update(market)
        features.update(_calendar_vector(date))
        features.update(_history_vector(home_records, date, "home", windows))
        features.update(_history_vector(away_records, date, "away", windows))
        if len(features) != int(cfg["features"]["total_count"]):
            raise AssertionError(f"Predictor count is {len(features)}, expected 112")
        result = str(match["FTR"])
        if result not in CLASS_ORDER:
            raise ValueError(f"Unexpected full-time result: {result}")
        record: dict[str, Any] = {
            "MatchDate": date,
            "League": league,
            "HomeTeam": home,
            "AwayTeam": away,
            "SourceRow": int(match["SourceRow"]),
            "Target": CLASS_ORDER.index(result),
        }
        record.update(features)
        rows.append(record)
        market_matrices.append(probability_matrix)

        home_goals = float(match["FTHG"])
        away_goals = float(match["FTAG"])
        if result == "H":
            home_points, away_points, home_outcome, away_outcome = 3.0, 0.0, "W", "L"
        elif result == "D":
            home_points, away_points, home_outcome, away_outcome = 1.0, 1.0, "D", "D"
        else:
            home_points, away_points, home_outcome, away_outcome = 0.0, 3.0, "L", "W"
        home_records.append({"date": date, "goals_for": home_goals, "goals_against": away_goals, "points": home_points, "outcome": home_outcome})
        away_records.append({"date": date, "goals_for": away_goals, "goals_against": home_goals, "points": away_points, "outcome": away_outcome})

    frame = pd.DataFrame(rows).sort_values(["MatchDate", "League", "SourceRow"], kind="mergesort").reset_index(drop=True)
    matrix = np.stack(market_matrices, axis=0)
    return frame, matrix


def prepare_data(cfg: dict[str, Any]) -> dict[str, Path]:
    from .data import load_raw_matches

    processed_dir = resolve_path(cfg, "processed_dir")
    processed_dir.mkdir(parents=True, exist_ok=True)
    frame, market = build_features(load_raw_matches(cfg), cfg)
    metadata = ["MatchDate", "League", "HomeTeam", "AwayTeam", "SourceRow", "Target"]
    feature_names = [column for column in frame.columns if column not in metadata]
    if len(feature_names) != 112:
        raise AssertionError("Prepared feature registry is not 112 columns")
    frame.to_csv(processed_dir / "matches_with_features.csv", index=False)
    np.save(processed_dir / "market_probabilities.npy", market)
    (processed_dir / "feature_registry.json").write_text(json.dumps(feature_names, indent=2), encoding="utf-8")
    return {
        "frame": processed_dir / "matches_with_features.csv",
        "market": processed_dir / "market_probabilities.npy",
        "registry": processed_dir / "feature_registry.json",
    }


def load_prepared(cfg: dict[str, Any]) -> tuple[pd.DataFrame, np.ndarray, list[str]]:
    processed_dir = resolve_path(cfg, "processed_dir")
    frame = pd.read_csv(processed_dir / "matches_with_features.csv", parse_dates=["MatchDate"])
    market = np.load(processed_dir / "market_probabilities.npy")
    registry = json.loads((processed_dir / "feature_registry.json").read_text(encoding="utf-8"))
    return frame, market, registry
