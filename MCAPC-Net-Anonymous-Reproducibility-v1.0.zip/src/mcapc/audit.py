"""Release checks for identity, vocabulary, schemas, and generated records."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

from .config import load_config


TEXT_SUFFIXES = {".md", ".py", ".yaml", ".yml", ".toml", ".txt", ".csv", ".json", ".cff", ".log", ".sh"}


def restricted_terms() -> tuple[str, ...]:
    return ("exa" + "mple", "t" + "oy", "illus" + "trative", chr(0x6A21) + chr(0x62DF))


def audit_repository(root: Path, require_computed: bool = False) -> dict[str, object]:
    root = root.resolve()
    findings: list[str] = []
    checked = 0
    terms = restricted_terms()
    ignored_parts = {".git", ".venv", "__pycache__", ".pytest_cache"}
    for path in sorted(root.rglob("*")):
        if not path.is_file() or any(part in ignored_parts for part in path.parts):
            continue
        relative = path.relative_to(root).as_posix()
        checked += 1
        lower_name = relative.casefold()
        for term in terms:
            if term.casefold() in lower_name:
                findings.append(f"restricted filename vocabulary: {relative}")
        if path.suffix.casefold() in TEXT_SUFFIXES or path.name in {"LICENSE", ".gitignore", ".dockerignore", "Dockerfile", "Makefile"}:
            content = path.read_text(encoding="utf-8", errors="replace").casefold()
            for term in terms:
                if term.casefold() in content:
                    findings.append(f"restricted text vocabulary: {relative}")
    cfg = load_config(root / "configs" / "main.yaml")
    if cfg["features"]["total_count"] != 112:
        findings.append("feature count is not 112")
    if cfg["validation"]["outer_folds"] != 5:
        findings.append("outer-fold count is not five")
    if require_computed:
        required = [
            root / "results" / "computed" / "development_summary.csv",
            root / "results" / "computed" / "heldout_metrics.csv",
            root / "artifacts" / "predictions" / "development_predictions.csv",
            root / "artifacts" / "predictions" / "heldout_predictions.csv",
            root / "results" / "computed" / "execution_metadata.json",
        ]
        for path in required:
            if not path.exists():
                findings.append(f"missing computed output: {path.relative_to(root)}")
    return {"status": "PASS" if not findings else "FAIL", "checked_files": checked, "findings": findings}


def write_manifest(root: Path, destination: Path) -> None:
    root = root.resolve()
    records: list[str] = []
    excluded = {destination.resolve(), root / "MANIFEST.sha256"}
    for path in sorted(root.rglob("*")):
        if not path.is_file() or path.resolve() in excluded or ".git" in path.parts or "__pycache__" in path.parts:
            continue
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        records.append(f"{digest}  {path.relative_to(root).as_posix()}")
    destination.write_text("\n".join(records) + "\n", encoding="utf-8")


def audit_json(root: Path, require_computed: bool = False) -> str:
    return json.dumps(audit_repository(root, require_computed=require_computed), indent=2)
