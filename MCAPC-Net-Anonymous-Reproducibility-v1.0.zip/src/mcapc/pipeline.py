"""End-to-end chronological experiment orchestration."""

from __future__ import annotations

import json
import logging
import platform
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import joblib
import numpy as np
import pandas as pd
from sklearn.metrics import log_loss

from .analysis import calibration_sensitivity, decision_table, residual_diagnostics
from .baselines import fit_predict_baselines
from .calibration import FRMCCM, SMTBCM, MultinomialStacking, OneVsRestIsotonic, OneVsRestPlatt, OptimizedProbabilityPool
from .config import config_digest, resolve_path
from .diagnostics import run_diagnostics
from .features import load_prepared
from .metrics import brier_score, bootstrap_metric, calibration_error, evaluate_probabilities, fold_summary, holm_adjust, normalize_probabilities, paired_rps_bootstrap, ranked_probability_score
from .splits import ExpandingWindowSplitter, inner_chronological_split
from .training import FoldPreprocessor, predict_network, train_network


LOGGER = logging.getLogger("mcapc")


def _league_indices(values: pd.Series, leagues: list[str]) -> np.ndarray:
    mapping = {name: index for index, name in enumerate(leagues)}
    return np.array([mapping.get(str(value), -1) for value in values], dtype=int)


def _market_models(market_train: np.ndarray, y_train: np.ndarray, market_validation: np.ndarray) -> tuple[dict[str, np.ndarray], dict[str, Any]]:
    fitted: dict[str, Any] = {}
    prediction: dict[str, np.ndarray] = {
        "MarketAvgClose": market_validation[:, 0, :],
        "MarketB365Close": market_validation[:, 1, :],
        "MarketAvgOpen": market_validation[:, 2, :],
        "MarketB365Open": market_validation[:, 3, :],
        "EqualMarketEnsemble": market_validation.mean(axis=1),
    }
    for name, estimator in {
        "FR-MCCM": FRMCCM(),
        "SMTBCM": SMTBCM(),
        "OptimizedLinearProbabilityPool": OptimizedProbabilityPool(),
        "MultinomialLogisticStacking": MultinomialStacking(),
    }.items():
        fitted[name] = estimator.fit(market_train, y_train)
        prediction[name] = fitted[name].predict_proba(market_validation)
    closing_train = market_train[:, 1, :]
    closing_validation = market_validation[:, 1, :]
    fitted["PlattCalibration"] = OneVsRestPlatt().fit(closing_train, y_train)
    fitted["IsotonicCalibration"] = OneVsRestIsotonic().fit(closing_train, y_train)
    prediction["PlattCalibration"] = fitted["PlattCalibration"].predict_proba(closing_validation)
    prediction["IsotonicCalibration"] = fitted["IsotonicCalibration"].predict_proba(closing_validation)
    return {name: normalize_probabilities(values) for name, values in prediction.items()}, fitted


def _select_training_plan(
    x_raw: np.ndarray,
    market: np.ndarray,
    y: np.ndarray,
    league: np.ndarray,
    cfg: dict[str, Any],
    seed: int,
) -> tuple[float, int, list[dict[str, float]]]:
    all_indices = np.arange(len(y))
    inner_train, inner_validation = inner_chronological_split(all_indices, float(cfg["validation"]["inner_validation_fraction"]))
    preprocessing = FoldPreprocessor.fit(x_raw[inner_train])
    x_train = preprocessing.transform(x_raw[inner_train])
    x_validation = preprocessing.transform(x_raw[inner_validation])
    teacher = SMTBCM().fit(market[inner_train], y[inner_train])
    teacher_train = teacher.predict_proba(market[inner_train])
    teacher_validation = teacher.predict_proba(market[inner_validation])
    traces: list[dict[str, float]] = []
    best_alpha = float(cfg["model"]["selected_alpha"])
    best_epoch = 1
    best_score = float("inf")
    for alpha in cfg["model"]["alpha_candidates"]:
        model, history = train_network(
            x_train,
            market[inner_train],
            teacher_train,
            league[inner_train],
            y[inner_train],
            x_validation,
            market[inner_validation],
            teacher_validation,
            league[inner_validation],
            y[inner_validation],
            cfg,
            seed,
            float(alpha),
        )
        del model
        chosen = min(history, key=lambda row: row["validation_rps"])
        trace = {"alpha": float(alpha), "validation_rps": float(chosen["validation_rps"]), "selected_epoch": float(chosen["epoch"])}
        traces.append(trace)
        if trace["validation_rps"] < best_score:
            best_score = trace["validation_rps"]
            best_alpha = float(alpha)
            best_epoch = int(trace["selected_epoch"])
    return best_alpha, best_epoch, traces


def _prediction_rows(metadata: pd.DataFrame, y: np.ndarray, model_name: str, probability: np.ndarray, fold: int | str) -> pd.DataFrame:
    return pd.DataFrame(
        {
            "fold": fold,
            "date": metadata["MatchDate"].astype(str).to_numpy(),
            "league": metadata["League"].to_numpy(),
            "home_team": metadata["HomeTeam"].to_numpy(),
            "away_team": metadata["AwayTeam"].to_numpy(),
            "target": y,
            "model": model_name,
            "p_home": probability[:, 0],
            "p_draw": probability[:, 1],
            "p_away": probability[:, 2],
        }
    )


def run_experiment(cfg: dict[str, Any]) -> dict[str, Path]:
    import torch

    frame, market, feature_names = load_prepared(cfg)
    feature_values = frame[feature_names].to_numpy(dtype=float)
    targets = frame["Target"].to_numpy(dtype=int)
    development_leagues = list(cfg["study"]["development_leagues"])
    development_mask = frame["League"].isin(development_leagues).to_numpy()
    heldout_mask = frame["League"].isin(cfg["study"]["heldout_leagues"]).to_numpy()
    development_positions = np.flatnonzero(development_mask)
    heldout_positions = np.flatnonzero(heldout_mask)
    development = frame.iloc[development_positions].reset_index(drop=True)
    heldout = frame.iloc[heldout_positions].reset_index(drop=True)
    x_development = feature_values[development_positions]
    market_development = market[development_positions]
    y_development = targets[development_positions]
    league_development = _league_indices(development["League"], development_leagues)
    if len(development) != 1140 or len(heldout) != 612:
        raise AssertionError("Prepared cohort sizes do not match the registered study design")

    result_dir = resolve_path(cfg, "result_dir")
    prediction_dir = resolve_path(cfg, "prediction_dir")
    model_dir = resolve_path(cfg, "model_dir")
    for directory in (result_dir, prediction_dir, model_dir):
        directory.mkdir(parents=True, exist_ok=True)
    splitter = ExpandingWindowSplitter(
        initial_train=int(cfg["validation"]["initial_train"]),
        validation_size=int(cfg["validation"]["validation_size"]),
        folds=int(cfg["validation"]["outer_folds"]),
    )
    metric_rows: list[dict[str, Any]] = []
    prediction_frames: list[pd.DataFrame] = []
    selection_rows: list[dict[str, Any]] = []
    fold_epoch_registry: dict[int, int] = {}
    boundaries = [
        {
            "outer_fold": fold.number,
            "train_start": int(fold.train_indices.min()),
            "train_end": int(fold.train_indices.max()),
            "train_n": len(fold.train_indices),
            "validation_start": int(fold.validation_indices.min()),
            "validation_end": int(fold.validation_indices.max()),
            "validation_n": len(fold.validation_indices),
        }
        for fold in splitter.split(len(development))
    ]
    pd.DataFrame(boundaries).to_csv(result_dir / "fold_boundaries.csv", index=False)
    for fold in splitter.split(len(development)):
        seed = int(cfg["validation"]["seeds"][fold.number - 1])
        train = fold.train_indices
        validation = fold.validation_indices
        LOGGER.info("outer_fold=%s train=%s validation=%s seed=%s", fold.number, len(train), len(validation), seed)
        selected_alpha, selected_epoch, traces = _select_training_plan(
            x_development[train], market_development[train], y_development[train], league_development[train], cfg, seed
        )
        fold_epoch_registry[fold.number] = selected_epoch
        for row in traces:
            selection_rows.append({"outer_fold": fold.number, **row, "selected": bool(row["alpha"] == selected_alpha)})
        preprocessing = FoldPreprocessor.fit(x_development[train])
        x_train = preprocessing.transform(x_development[train])
        x_validation = preprocessing.transform(x_development[validation])
        market_prediction, fitted_market = _market_models(market_development[train], y_development[train], market_development[validation])
        teacher = fitted_market["SMTBCM"]
        teacher_train = teacher.predict_proba(market_development[train])
        teacher_validation = teacher.predict_proba(market_development[validation])
        model, history = train_network(
            x_train,
            market_development[train],
            teacher_train,
            league_development[train],
            y_development[train],
            x_validation,
            market_development[validation],
            teacher_validation,
            league_development[validation],
            y_development[validation],
            cfg,
            seed,
            selected_alpha,
            fixed_epochs=selected_epoch,
        )
        network_output = predict_network(model, x_validation, market_development[validation], teacher_validation, league_development[validation])
        all_predictions = {**market_prediction, "MCAPC-Net": network_output["probabilities"]}
        conventional, failures = fit_predict_baselines(x_development[train], y_development[train], x_development[validation], cfg, seed)
        all_predictions.update(conventional)
        for model_name, probability in all_predictions.items():
            metrics = evaluate_probabilities(y_development[validation], probability, bins=int(cfg["inference"]["calibration_bins"]))
            metric_rows.append({"outer_fold": fold.number, "model": model_name, "n": len(validation), **metrics})
            prediction_frames.append(_prediction_rows(development.iloc[validation], y_development[validation], model_name, probability, fold.number))
        if failures:
            (result_dir / f"baseline_failures_fold_{fold.number}.json").write_text(json.dumps(failures, indent=2), encoding="utf-8")
        pd.DataFrame(history).to_csv(result_dir / f"training_history_fold_{fold.number}.csv", index=False)
        torch.save(model.state_dict(), model_dir / f"mcapc_fold_{fold.number}.pt")
        joblib.dump(preprocessing, model_dir / f"preprocessing_fold_{fold.number}.joblib")

    fold_metrics = pd.DataFrame(metric_rows)
    fold_metrics.to_csv(result_dir / "development_fold_metrics.csv", index=False)
    pd.concat(prediction_frames, ignore_index=True).to_csv(prediction_dir / "development_predictions.csv", index=False)
    pd.DataFrame(selection_rows).to_csv(result_dir / "alpha_selection.csv", index=False)
    summaries: list[dict[str, Any]] = []
    for (model_name, metric), values in fold_metrics.set_index(["outer_fold", "model"]).drop(columns="n").stack().groupby(level=[1, 2]):
        summary = fold_summary(values.to_numpy(dtype=float))
        summaries.append({"model": model_name, "metric": metric, **summary})
    pd.DataFrame(summaries).to_csv(result_dir / "development_summary.csv", index=False)

    development_seed_rows: list[dict[str, Any]] = []
    for stability_seed in cfg["validation"]["seeds"]:
        seed_probabilities: list[np.ndarray] = []
        seed_targets: list[np.ndarray] = []
        for fold in splitter.split(len(development)):
            train = fold.train_indices
            validation = fold.validation_indices
            preprocessing = FoldPreprocessor.fit(x_development[train])
            local_train = preprocessing.transform(x_development[train])
            local_validation = preprocessing.transform(x_development[validation])
            teacher = SMTBCM().fit(market_development[train], y_development[train])
            model, _ = train_network(
                local_train,
                market_development[train],
                teacher.predict_proba(market_development[train]),
                league_development[train],
                y_development[train],
                local_validation,
                market_development[validation],
                teacher.predict_proba(market_development[validation]),
                league_development[validation],
                y_development[validation],
                cfg,
                int(stability_seed),
                float(cfg["model"]["selected_alpha"]),
                fixed_epochs=fold_epoch_registry[fold.number],
            )
            seed_probabilities.append(
                predict_network(
                    model,
                    local_validation,
                    market_development[validation],
                    teacher.predict_proba(market_development[validation]),
                    league_development[validation],
                )["probabilities"]
            )
            seed_targets.append(y_development[validation])
        development_seed_rows.append(
            {
                "seed": int(stability_seed),
                **evaluate_probabilities(np.concatenate(seed_targets), np.concatenate(seed_probabilities), bins=int(cfg["inference"]["calibration_bins"])),
            }
        )
    pd.DataFrame(development_seed_rows).to_csv(result_dir / "seed_stability.csv", index=False)

    final_preprocessing = FoldPreprocessor.fit(x_development)
    x_final = final_preprocessing.transform(x_development)
    x_heldout = final_preprocessing.transform(feature_values[heldout_positions])
    final_teacher = SMTBCM().fit(market_development, y_development)
    teacher_final = final_teacher.predict_proba(market_development)
    teacher_heldout = final_teacher.predict_proba(market[heldout_positions])
    final_alpha = float(cfg["model"]["selected_alpha"])
    _, _, final_traces = _select_training_plan(
        x_development,
        market_development,
        y_development,
        league_development,
        cfg,
        int(cfg["validation"]["seeds"][0]),
    )
    final_trace = next(row for row in final_traces if float(row["alpha"]) == final_alpha)
    final_epoch = int(final_trace["selected_epoch"])
    pd.DataFrame(final_traces).to_csv(result_dir / "final_duration_selection.csv", index=False)
    seed_outputs: list[dict[str, np.ndarray]] = []
    seed_rows: list[dict[str, Any]] = []
    final_histories: list[pd.DataFrame] = []
    for seed in cfg["validation"]["seeds"]:
        final_model, final_history = train_network(
            x_final,
            market_development,
            teacher_final,
            league_development,
            y_development,
            x_final,
            market_development,
            teacher_final,
            league_development,
            y_development,
            cfg,
            int(seed),
            final_alpha,
            fixed_epochs=final_epoch,
        )
        seed_output = predict_network(
            final_model,
            x_heldout,
            market[heldout_positions],
            teacher_heldout,
            np.full(len(heldout), -1, dtype=int),
        )
        seed_outputs.append(seed_output)
        seed_rows.append({"seed": int(seed), **evaluate_probabilities(targets[heldout_positions], seed_output["probabilities"])})
        history_frame = pd.DataFrame(final_history)
        history_frame.insert(0, "seed", int(seed))
        final_histories.append(history_frame)
        torch.save(final_model.state_dict(), model_dir / f"mcapc_final_seed_{seed}.pt")
    heldout_output = {name: np.mean([output[name] for output in seed_outputs], axis=0) for name in seed_outputs[0]}
    pd.DataFrame(seed_rows).to_csv(result_dir / "heldout_seed_stability.csv", index=False)
    heldout_market, _ = _market_models(market_development, y_development, market[heldout_positions])
    heldout_predictions = {**heldout_market, "MCAPC-Net": heldout_output["probabilities"]}
    conventional_heldout, heldout_failures = fit_predict_baselines(
        x_development, y_development, feature_values[heldout_positions], cfg, int(cfg["validation"]["seeds"][0])
    )
    heldout_predictions.update(conventional_heldout)
    if heldout_failures:
        (result_dir / "baseline_failures_heldout.json").write_text(json.dumps(heldout_failures, indent=2), encoding="utf-8")
    heldout_rows: list[dict[str, Any]] = []
    heldout_prediction_frames: list[pd.DataFrame] = []
    for model_name, probability in heldout_predictions.items():
        for league_name in [*cfg["study"]["heldout_leagues"], "Combined"]:
            subset = np.ones(len(heldout), dtype=bool) if league_name == "Combined" else heldout["League"].eq(league_name).to_numpy()
            metrics = evaluate_probabilities(targets[heldout_positions][subset], probability[subset], bins=int(cfg["inference"]["calibration_bins"]))
            heldout_rows.append({"cohort": league_name, "model": model_name, "n": int(subset.sum()), **metrics})
        heldout_prediction_frames.append(_prediction_rows(heldout, targets[heldout_positions], model_name, probability, "heldout"))
    pd.DataFrame(heldout_rows).to_csv(result_dir / "heldout_metrics.csv", index=False)
    pd.concat(heldout_prediction_frames, ignore_index=True).to_csv(prediction_dir / "heldout_predictions.csv", index=False)
    calibration_frames = []
    for calibration_model in ("MCAPC-Net", "SMTBCM", "MarketB365Close", "FR-MCCM"):
        frame_part = calibration_sensitivity(targets[heldout_positions], heldout_predictions[calibration_model])
        frame_part.insert(0, "model", calibration_model)
        calibration_frames.append(frame_part)
    pd.concat(calibration_frames, ignore_index=True).to_csv(result_dir / "calibration_sensitivity.csv", index=False)
    residual_diagnostics(
        targets[heldout_positions], teacher_heldout, heldout_output["probabilities"], heldout_output["correction"]
    ).to_csv(result_dir / "residual_diagnostics.csv", index=False)
    closing_odds = 1.0 / np.clip(market[heldout_positions, 1, :], 1.0e-8, None)
    decision_frames = []
    for decision_model in ("MCAPC-Net", "FR-MCCM", "MarketB365Close", "MultinomialLogisticStacking"):
        frame_part = decision_table(
            targets[heldout_positions],
            heldout_predictions[decision_model],
            closing_odds,
            cfg["inference"]["decision_thresholds"],
            strata=heldout["League"].to_numpy(),
            replications=int(cfg["inference"]["bootstrap_replications"]),
            seed=int(cfg["validation"]["seeds"][0]),
        )
        frame_part.insert(0, "model", decision_model)
        decision_frames.append(frame_part)
    pd.concat(decision_frames, ignore_index=True).to_csv(result_dir / "decision_analysis.csv", index=False)
    pd.concat(final_histories, ignore_index=True).to_csv(result_dir / "final_training_history.csv", index=False)
    uncertainty_rows: list[dict[str, Any]] = []
    strata = heldout["League"].to_numpy()
    metric_registry = {
        "rps": ranked_probability_score,
        "log_loss": lambda y, p: float(log_loss(y, p, labels=[0, 1, 2])),
        "brier": brier_score,
        "ece_15": lambda y, p: calibration_error(y, p, bins=int(cfg["inference"]["calibration_bins"]))[0],
    }
    uncertainty_models = (
        "MCAPC-Net",
        "MultinomialLogisticStacking",
        "OptimizedLinearProbabilityPool",
        "SMTBCM",
        "PlattCalibration",
        "MarketB365Close",
        "FR-MCCM",
    )
    for model_name in uncertainty_models:
        probability = heldout_predictions[model_name]
        for metric_name, metric_function in metric_registry.items():
            interval = bootstrap_metric(
                targets[heldout_positions],
                probability,
                strata,
                metric_function,
                replications=int(cfg["inference"]["bootstrap_replications"]),
                seed=int(cfg["validation"]["seeds"][0]),
            )
            uncertainty_rows.append({"model": model_name, "metric": metric_name, **interval})
    pd.DataFrame(uncertainty_rows).to_csv(result_dir / "comparator_uncertainty.csv", index=False)
    paired_rows: list[dict[str, Any]] = []
    for comparator in ("FR-MCCM", "MarketB365Close", "MultinomialLogisticStacking"):
        row = paired_rps_bootstrap(
            targets[heldout_positions],
            heldout_output["probabilities"],
            heldout_predictions[comparator],
            strata,
            replications=int(cfg["inference"]["bootstrap_replications"]),
            seed=int(cfg["validation"]["seeds"][0]),
        )
        family = "prespecified" if comparator in {"FR-MCCM", "MarketB365Close"} else "secondary"
        paired_rows.append({"first_model": "MCAPC-Net", "second_model": comparator, "comparison_family": family, **row})
    family_rows = [row for row in paired_rows if row["comparison_family"] == "prespecified"]
    adjusted = holm_adjust([float(row["p_value"]) for row in family_rows])
    for row in paired_rows:
        row["holm_p_value"] = float("nan")
    for row, value in zip(family_rows, adjusted):
        row["holm_p_value"] = value
    pd.DataFrame(paired_rows).to_csv(result_dir / "paired_bootstrap.csv", index=False)
    attention_rows = []
    for source_index, source_name in enumerate(("AvgClose", "B365Close", "AvgOpen", "B365Open")):
        values = heldout_output["attention"][:, source_index]
        attention_rows.append({"source": source_name, "mean": float(values.mean()), "sd": float(values.std(ddof=1)), "minimum": float(values.min()), "maximum": float(values.max())})
    pd.DataFrame(attention_rows).to_csv(result_dir / "attention_summary.csv", index=False)
    LOGGER.info("diagnostic_suite=started")
    run_diagnostics(
        x_development,
        y_development,
        market_development,
        league_development,
        feature_values[heldout_positions],
        targets[heldout_positions],
        market[heldout_positions],
        feature_names,
        heldout_output["probabilities"],
        cfg,
        final_epoch,
        result_dir,
    )
    LOGGER.info("diagnostic_suite=completed")
    joblib.dump(final_preprocessing, model_dir / "preprocessing_final.joblib")
    joblib.dump(final_teacher, model_dir / "teacher_final.joblib")
    environment = {
        "completed_at_utc": datetime.now(timezone.utc).isoformat(),
        "python": sys.version,
        "platform": platform.platform(),
        "numpy": np.__version__,
        "pandas": pd.__version__,
        "torch": torch.__version__,
        "config_sha256": config_digest(cfg),
        "final_epoch": final_epoch,
        "final_alpha": final_alpha,
        "ensemble_seeds": cfg["validation"]["seeds"],
    }
    (result_dir / "execution_metadata.json").write_text(json.dumps(environment, indent=2), encoding="utf-8")
    return {"results": result_dir, "predictions": prediction_dir, "models": model_dir}
