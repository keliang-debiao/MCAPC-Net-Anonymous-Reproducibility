"""Chronological split construction."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Iterator

import numpy as np


@dataclass(frozen=True)
class Fold:
    number: int
    train_indices: np.ndarray
    validation_indices: np.ndarray


class ExpandingWindowSplitter:
    def __init__(self, initial_train: int = 190, validation_size: int = 190, folds: int = 5):
        self.initial_train = int(initial_train)
        self.validation_size = int(validation_size)
        self.folds = int(folds)

    def split(self, size: int) -> Iterator[Fold]:
        required = self.initial_train + self.folds * self.validation_size
        if size < required:
            raise ValueError(f"Need at least {required} ordered rows, received {size}")
        for number in range(1, self.folds + 1):
            train_end = self.initial_train + (number - 1) * self.validation_size
            validation_end = train_end + self.validation_size
            yield Fold(
                number=number,
                train_indices=np.arange(0, train_end, dtype=int),
                validation_indices=np.arange(train_end, validation_end, dtype=int),
            )


def inner_chronological_split(indices: np.ndarray, validation_fraction: float = 0.20) -> tuple[np.ndarray, np.ndarray]:
    indices = np.asarray(indices, dtype=int)
    if not 0.0 < validation_fraction < 1.0:
        raise ValueError("validation_fraction must be between zero and one")
    validation_count = max(1, int(round(len(indices) * validation_fraction)))
    if validation_count >= len(indices):
        raise ValueError("Inner split leaves no training rows")
    return indices[:-validation_count], indices[-validation_count:]
