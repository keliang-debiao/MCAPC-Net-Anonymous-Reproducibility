"""Probability metrics, calibration, uncertainty, and decision analysis."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

import numpy as np
from sklearn.metrics import accuracy_score, f1_score, log_loss, roc_auc_score
from sklearn.preprocessing import label_binarize


EPS = 1.0e-12


def normalize_probabilities(probabilities: np.ndarray) -> np.ndarray:
    values = np.asarray(probabilities, dtype=float)
    values = np.clip(values, EPS, np.inf)
    return values / values.sum(axis=1, keepdims=True)


def ranked_probability_score(y_true: np.ndarray, probabilities: np.ndarray) -> float:
    y_true = np.asarray(y_true, dtype=int)
    probabilities = normalize_probabilities(probabilities)
    observed = np.eye(3, dtype=float)[y_true]
    cumulative_p = np.cumsum(probabilities, axis=1)[:, :-1]
    cumulative_y = np.cumsum(observed, axis=1)[:, :-1]
    return float(np.mean(np.sum((cumulative_p - cumulative_y) ** 2, axis=1) / 2.0))


def per_match_rps(y_true: np.ndarray, probabilities: np.ndarray) -> np.ndarray:
    y_true = np.asarray(y_true, dtype=int)
    probabilities = normalize_probabilities(probabilities)
    observed = np.eye(3, dtype=float)[y_true]
    cumulative_p = np.cumsum(probabilities, axis=1)[:, :-1]
    cumulative_y = np.cumsum(observed, axis=1)[:, :-1]
    return np.sum((cumulative_p - cumulative_y) ** 2, axis=1) / 2.0


def brier_score(y_true: np.ndarray, probabilities: np.ndarray) -> float:
    observed = np.eye(3, dtype=float)[np.asarray(y_true, dtype=int)]
    return float(np.mean((normalize_probabilities(probabilities) - observed) ** 2))


def calibration_error(y_true: np.ndarray, probabilities: np.ndarray, bins: int = 15, equal_frequency: bool = False) -> tuple[float, float]:
    y_true = np.asarray(y_true, dtype=int)
    probabilities = normalize_probabilities(probabilities)
    prediction = probabilities.argmax(axis=1)
    confidence = probabilities.max(axis=1)
    correct = (prediction == y_true).astype(float)
    if equal_frequency:
        order = np.argsort(confidence, kind="mergesort")
        groups = np.array_split(order, bins)
    else:
        edges = np.linspace(0.0, 1.0, bins + 1)
        groups = [np.flatnonzero((confidence >= edges[i]) & (confidence < edges[i + 1] if i < bins - 1 else confidence <= edges[i + 1])) for i in range(bins)]
    gaps: list[float] = []
    weighted = 0.0
    for group in groups:
        if len(group) == 0:
            continue
        gap = abs(float(correct[group].mean() - confidence[group].mean()))
        gaps.append(gap)
        weighted += len(group) * gap / len(y_true)
    return float(weighted), float(max(gaps) if gaps else 0.0)


def evaluate_probabilities(y_true: np.ndarray, probabilities: np.ndarray, bins: int = 15) -> dict[str, float]:
    y_true = np.asarray(y_true, dtype=int)
    probabilities = normalize_probabilities(probabilities)
    prediction = probabilities.argmax(axis=1)
    ece, mce = calibration_error(y_true, probabilities, bins=bins)
    binary = label_binarize(y_true, classes=[0, 1, 2])
    try:
        auc = float(roc_auc_score(binary, probabilities, average="macro", multi_class="ovr"))
    except ValueError:
        auc = float("nan")
    return {
        "rps": ranked_probability_score(y_true, probabilities),
        "log_loss": float(log_loss(y_true, probabilities, labels=[0, 1, 2])),
        "brier": brier_score(y_true, probabilities),
        "ece": ece,
        "mce": mce,
        "accuracy": float(accuracy_score(y_true, prediction)),
        "macro_f1": float(f1_score(y_true, prediction, average="macro", zero_division=0)),
        "auc_ovr": auc,
    }


def fold_summary(values: np.ndarray, confidence: float = 0.95) -> dict[str, float]:
    from scipy.stats import t

    values = np.asarray(values, dtype=float)
    mean = float(values.mean())
    sd = float(values.std(ddof=1))
    se = float(sd / np.sqrt(len(values)))
    critical = float(t.ppf((1.0 + confidence) / 2.0, df=len(values) - 1))
    return {"mean": mean, "sd": sd, "se": se, "ci_lower": mean - critical * se, "ci_upper": mean + critical * se}


def stratified_bootstrap_indices(strata: np.ndarray, replications: int, seed: int) -> list[np.ndarray]:
    strata = np.asarray(strata)
    generator = np.random.default_rng(seed)
    groups = [np.flatnonzero(strata == value) for value in np.unique(strata)]
    outputs: list[np.ndarray] = []
    for _ in range(replications):
        outputs.append(np.concatenate([generator.choice(group, size=len(group), replace=True) for group in groups]))
    return outputs


def bootstrap_metric(
    y_true: np.ndarray,
    probabilities: np.ndarray,
    strata: np.ndarray,
    metric: Callable[[np.ndarray, np.ndarray], float],
    replications: int = 10000,
    seed: int = 2026,
) -> dict[str, float]:
    estimates = np.array([metric(y_true[index], probabilities[index]) for index in stratified_bootstrap_indices(strata, replications, seed)])
    return {
        "point": float(metric(y_true, probabilities)),
        "ci_lower": float(np.quantile(estimates, 0.025)),
        "ci_upper": float(np.quantile(estimates, 0.975)),
    }


def paired_rps_bootstrap(
    y_true: np.ndarray,
    first: np.ndarray,
    second: np.ndarray,
    strata: np.ndarray,
    replications: int = 10000,
    seed: int = 2026,
) -> dict[str, float]:
    difference = per_match_rps(y_true, first) - per_match_rps(y_true, second)
    estimates = np.array([difference[index].mean() for index in stratified_bootstrap_indices(strata, replications, seed)])
    centered = estimates - estimates.mean()
    observed = float(difference.mean())
    p_value = float(min(1.0, 2.0 * min(np.mean(centered <= observed), np.mean(centered >= observed))))
    effect = float(abs(observed / difference.std(ddof=1))) if difference.std(ddof=1) > 0 else 0.0
    return {
        "mean_difference": observed,
        "ci_lower": float(np.quantile(estimates, 0.025)),
        "ci_upper": float(np.quantile(estimates, 0.975)),
        "p_value": p_value,
        "paired_effect": effect,
    }


def holm_adjust(p_values: list[float]) -> list[float]:
    values = np.asarray(p_values, dtype=float)
    order = np.argsort(values)
    adjusted = np.empty_like(values)
    running = 0.0
    size = len(values)
    for rank, index in enumerate(order):
        running = max(running, (size - rank) * values[index])
        adjusted[index] = min(1.0, running)
    return adjusted.tolist()


@dataclass(frozen=True)
class DecisionResult:
    decisions: int
    hit_rate: float
    gross_roi: float


def decision_value(y_true: np.ndarray, probabilities: np.ndarray, closing_odds: np.ndarray, threshold: float) -> DecisionResult:
    y_true = np.asarray(y_true, dtype=int)
    probabilities = normalize_probabilities(probabilities)
    closing_odds = np.asarray(closing_odds, dtype=float)
    edge = probabilities * closing_odds - 1.0
    choice = edge.argmax(axis=1)
    best = edge[np.arange(len(edge)), choice]
    selected = np.flatnonzero(best >= threshold)
    if len(selected) == 0:
        return DecisionResult(0, 0.0, 0.0)
    wins = choice[selected] == y_true[selected]
    returns = np.where(wins, closing_odds[selected, choice[selected]] - 1.0, -1.0)
    return DecisionResult(int(len(selected)), float(wins.mean()), float(returns.mean()))
